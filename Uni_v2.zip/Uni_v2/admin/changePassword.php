<?php
	require_once '../config/session.php';
    require_once '../config/db_con.php';		
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>SmartHub</title>

<!-- Global stylesheets -->
<link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
<link href="../assets/css/icons/icomoon/styles.css" rel="stylesheet" type="text/css">
<link href="../assets/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="../assets/css/core.css" rel="stylesheet" type="text/css">
<link href="../assets/css/components.css" rel="stylesheet" type="text/css">
<link href="../assets/css/colors.css" rel="stylesheet" type="text/css">
<!-- /global stylesheets -->


<!-- Global for the table -->
<link href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css">
<link href="https://cdn.datatables.net/buttons/1.5.2/css/buttons.dataTables.min.css" rel="stylesheet" type="text/css">
<!-- Global for the table -->

<!-- Core JS files -->
<script type="text/javascript" src="../assets/js/plugins/loaders/pace.min.js"></script>
<script type="text/javascript" src="../assets/js/core/libraries/jquery.min.js"></script>
<script type="text/javascript" src="../assets/js/core/libraries/bootstrap.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/loaders/blockui.min.js"></script>
<!-- /core JS files -->

<script type="text/javascript" src="../assets/js/plugins/notifications/jgrowl.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/ui/moment/moment.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/daterangepicker.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/anytime.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/picker.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/picker.date.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/picker.time.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/legacy.js"></script>

<script type="text/javascript" src="../assets/js/core/app.js"></script>
<script type="text/javascript" src="../assets/js/pages/picker_date.js"></script>

<script type="text/javascript" src="../assets/js/plugins/ui/ripple.min.js"></script>

<!-- Theme JS files -->
<script type="text/javascript" src="../assets/js/core/libraries/jquery_ui/interactions.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/forms/selects/select2.min.js"></script>

<script type="text/javascript" src="../assets/js/pages/form_select2.js"></script>

<script type="text/javascript" src="../assets/js/plugins/ui/ripple.min.js"></script>

</head>

<body id="background" class="layout-boxed navbar-bottom backpic">

		<!-- Main navbar AND Main menu-->
		<?php

			require_once '../Menu/menu_admin.php';

		?>
		<!-- /page header -->


	<!-- Page container -->
	<div class="page-container">
		<!-- Page content -->
		<div class="page-content" id="Div1">
			<!-- Main content -->
			<div class="content-wrapper">
				<!-- Traffic sources -->
				<div class="panel panel-flat">
					<div class="panel-heading">
						<h6 class="panel-title">Change Password</h6>
						<div class="heading-elements">
						</div>
					</div>
						<?php

						if(isset($_GET['err']) )
									{	
										if($_GET['err'] == 1 )
										{
										echo "<a href='changePassword.php'><div class='alert alert-danger alert-dismissible' role='alert'>
												<strong>Wrong!</strong> Current Password entred is not correct .
											</div></a>";
										}

										if($_GET['err'] == 2 )
										{
										echo "<a href='changePassword.php'><div class='alert alert-danger alert-dismissible' role='alert'>
												<strong>Wrong!</strong> New Password and confirmation does not match .
											</div></a>";
										}

										if($_GET['err'] == 3 )
										{
										echo "<a href='../logout.php'><div class='alert alert-success alert-dismissible' role='alert'>
												<strong>Success!</strong> Password was changed Successfully .
											</div></a>";
										}
									}
						?>


                    <div class="container-fluid" style="margin-top:5px;width:98%;">
                            <div class="col-lg-10">
                                    <form class="form-horizontal" action="PasswordChange.php" method="POST">
                                       <fieldset class="content-group">
                                           <legend class="text-bold"><i style="color:red;font-size:9px;">All fields are required *</i></legend>
   
                                           <div class="form-group">
                                               <label class="control-label col-lg-4 font1" style="text-align:right;">Enter Current Password</label>
                                               <div class="col-lg-8">
                                                   <div class="input-group input-group-xs">
                                                       <span class="input-group-addon"><i class="icon-key"></i></span>
                                                       <input type="password" name="currentPassword" class="form-control" placeholder="Enter Current Password" required autocomplete="off">
                                                   </div>
                                               </div>
                                           </div>
   
                                           <div class="form-group">
                                               <label class="control-label col-lg-4 font1" style="text-align:right;">Enter New Password</label>
                                               <div class="col-lg-8">
                                                   <div class="input-group input-group-xs">
                                                       <span class="input-group-addon"><i class=" icon-lock"></i></span>
                                                       <input type="password" name="newPassword" class="form-control" placeholder="Enter New Password" required autocomplete="off">
                                                   </div>
                                               </div>
                                           </div>
   
                                           <div class="form-group">
                                               <label class="control-label col-lg-4 font1" style="text-align:right;">Confirm New Password</label>
                                               <div class="col-lg-8">
                                                   <div class="input-group input-group-xs">
                                                       <span class="input-group-addon"><i class=" icon-lock"></i></span>
                                                       <input type="password" name="confirmPassword" class="form-control" placeholder="Confirm New Password" required autocomplete="off">
                                                   </div>
                                               </div>
                                           </div>
                                           <div class="form-group" style="float:right;">
                                                   <input type="submit" name="submit" class="btn btn-primary btn-xs" value="Change Password" >     
                                           </div>
                                       </fieldset>
                                      
                                   </form>
                               </div>
                    </div>
				</div>
				<!-- /traffic sources -->
			</div>
			<!-- /content area -->
		</div>
    <!-- /page content -->
	</div>
	<!-- footer-->
	<?php

	require_once '../footer/footer.php';

	?>
	<!-- /Footer -->

</body>
</html>
