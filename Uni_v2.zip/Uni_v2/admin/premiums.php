<?php
	require_once '../config/session.php';
    require_once '../config/db_con.php';		
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Uniturtle</title>

<!-- Global stylesheets -->
<link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
<link href="../assets/css/icons/icomoon/styles.css" rel="stylesheet" type="text/css">
<link href="../assets/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="../assets/css/core.css" rel="stylesheet" type="text/css">
<link href="../assets/css/components.css" rel="stylesheet" type="text/css">
<link href="../assets/css/colors.css" rel="stylesheet" type="text/css">
<!-- /global stylesheets -->


<!-- Global for the table -->
<link href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css">
<link href="https://cdn.datatables.net/buttons/1.5.2/css/buttons.dataTables.min.css" rel="stylesheet" type="text/css">
<!-- Global for the table -->

<!-- Core JS files -->
<script type="text/javascript" src="../assets/js/plugins/loaders/pace.min.js"></script>
<script type="text/javascript" src="../assets/js/core/libraries/jquery.min.js"></script>
<script type="text/javascript" src="../assets/js/core/libraries/bootstrap.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/loaders/blockui.min.js"></script>
<!-- /core JS files -->

<script type="text/javascript" src="../assets/js/plugins/notifications/jgrowl.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/ui/moment/moment.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/daterangepicker.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/anytime.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/picker.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/picker.date.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/picker.time.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/legacy.js"></script>

<script type="text/javascript" src="../assets/js/core/app.js"></script>
<script type="text/javascript" src="../assets/js/pages/picker_date.js"></script>

<script type="text/javascript" src="../assets/js/plugins/ui/ripple.min.js"></script>

<!-- Theme JS files -->
<script type="text/javascript" src="../assets/js/core/libraries/jquery_ui/interactions.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/forms/selects/select2.min.js"></script>

<script type="text/javascript" src="../assets/js/core/app.js"></script>
<script type="text/javascript" src="../assets/js/pages/form_select2.js"></script>

<script type="text/javascript" src="../assets/js/plugins/ui/ripple.min.js"></script>

</head>

<body id="background" class="layout-boxed navbar-bottom backpic">

	<!-- Main navbar AND Main menu-->
    <?php

        require_once '../Menu/menu_admin.php';

    ?>
    <!-- /page header -->


	<!-- Page container -->
	<div class="page-container">
		<!-- Page content -->
		<div class="page-content" id="Div1">
			<!-- Main content -->
			<div class="content-wrapper">
				<!-- Traffic sources -->
				<div class="panel panel-flat">
					<div class="panel-heading">
						<h6 class="panel-title">Premiums Management</h6>
                    </div>
                    <?php
                            if(isset($_GET['err']) )
                                        {	
                                            if($_GET['err'] == 3 )
                                            {
                                            echo "<a href='premiums.php'><div class='alert alert-success alert-dismissible' role='alert'>
                                                    <strong>Success!</strong> New Premium was successfully added to the list pending Activation .
                                                </div></a>";
                                            }
                                            
                                            if($_GET['err'] == 2 )
                                            {
                                            echo "<a href='premiums.php'><div class='alert alert-warning alert-dismissible' role='alert'>
                                                    <strong>Warning!</strong> The Premium code entered has already been used.
                                                </div></a>";
                                            }
                                        }
                        ?>
					<div class="container-fluid" style="margin-top:-50px;">
						<div class="row">
							<div class="col-lg-3" style="float:right;">
								<ul class="list-inline text-center">
									<li>
                                        <a href="#" class="btn border-indigo-400 text-indigo-400 btn-flat btn-rounded btn-icon btn-xs valign-text-bottom" data-toggle="modal" data-target="#myModal"><i class="icon-plus3"></i></a>
									</li>
									<li class="text-left">
										<div class="text-semibold">Add New Premium</div>
										<div class="text-muted top-1"><span class="status-mar border-success position-left"></span></div>
									</li>
								</ul>
								<div class="col-lg-10 col-lg-offset-1">
									<div class="content-group" id="total-online"></div>
								</div>
							</div>
						</div>
					</div>
                    <div id="reportsTable" style="width:98%;margin:auto;">
                     <table id="example" class="display" style="width:100%;font-size:10px;">
                         <thead>
                             <tr>
                                 <th style='text-align:center;'>Date Created</th>
                                 <th style='text-align:center;'>Premium Code</th>
                                 <th style='text-align:center;'>Premium Cover</th>
                                 <th style='text-align:center;'>Premium Name</th>
                                 <th style='text-align:center;'>Amount</th>
                             </tr>
                         </thead>
                         <tbody>
                         <?php	
									$sql  = "SELECT* FROM `premiums`";
									$result = mysqli_query($conn, $sql);

									if (mysqli_num_rows($result) > 0) {
										// output data of each row
										while($row = mysqli_fetch_assoc($result)) {
								echo "<tr class='odd gradeX'>
											<td style='text-align:center;'>{$row["date"]}</td>
											<td style='text-align:center;'>{$row["premCode"]}</td>
											<td style='text-align:right;'>K{$row["premiun_cover"]}.00</td>
											<td style='text-align:center;'>{$row["premName"]}</td>
											<td style='text-align:right;'>K{$row["premAmount"]}.00</td>";
									echo"</tr>";
									
                                        }
                                    }
								?>
                         </tbody>
                     </table>
                   </div>
				</div>
                <!-- /traffic sources -->
                <!-- Modal content number1 starts here-->
                <div class="modal fade" id="myModal" role="dialog">
                        <div class="modal-dialog">
                        <!-- Modal content-->
                        <div class="modal-content">
                            <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title">Add new Premium to the list</h4>
                            </div>
                            <div class="modal-body">
                            <form class="form-horizontal" action="addPremium.php" method="POST">
                                <fieldset class="content-group">
                                    <legend class="text-bold" style="font-size:10px;color:red;"><i>All fields are required*</i></legend>

                                    <div class="form-group client1">
                                        <label class="control-label col-lg-4" style="text-align:right;">Enter Premium Code</label>
                                        <div class="col-lg-6">
                                            <div class="input-group input-group-xlg">
                                                <span class="input-group-addon"></span>
                                                <input type="text" class="form-control" name="codet" required autocomplete="off">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group client1">
                                        <label class="control-label col-lg-4" style="text-align:right;">Enter Premium Name</label>
                                        <div class="col-lg-6">
                                            <div class="input-group input-group-lg">
                                                <span class="input-group-addon"></span>
                                                <input type="text" class="form-control"  name="name" required autocomplete="off">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group client1">
                                        <label class="control-label col-lg-4" style="text-align:right;">Enter Cover Amount</label>
                                        <div class="col-lg-6">
                                            <div class="input-group input-group-lg">
                                                <span class="input-group-addon"></span>
                                                <input type="text" class="form-control"  name="cover_amount" required autocomplete="off">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group client1">
                                        <label class="control-label col-lg-4" style="text-align:right;">Enter Amount</label>
                                        <div class="col-lg-6">
                                            <div class="input-group">
                                                <span class="input-group-addon"></span>
                                                <input type="text" class="form-control"  name="amount" required autocomplete="off">
                                            </div>
                                        </div>
                                    </div>
                                </fieldset>
                                <div class="btn-group btn-group-xs" style="margin-left:50px;">
                                    <button type="submit" name="submit" class="btn btn-success" style="height:24px;line-height:4px;">Add New Premium</button>
                                </div>
                            </form>
                            </div>
                        </div>
                        </div>
                    </div>


            </div>
            <!-- /content area -->
        </div>
            <!-- /page content -->
    </div>
	<!-- /page container -->
    <script>	
		$(document).ready(function() {
			$('#example').DataTable( {
				dom: 'Bfrtip',
				buttons: [
					{
						extend: 'copyHtml5',
						title: 'Uniturtule Transactions'
					},
					{
						extend: 'excelHtml5',
						title: 'Uniturtule Transactions'
					},
					{
						extend: 'csvHtml5',
						title: 'Uniturtule Transactions'
					},
					{
						extend: 'pdfHtml5',
						title: 'Uniturtule Transactions',
						orientation: 'landscape',
                		pageSize: 'LEGAL'
					},
					{
						extend: 'print',
						title: 'Uniturtule Transactions',
						orientation: 'landscape',
                		pageSize: 'LEGAL'
					}
				]
			} );
		} );
</script>
    
        <!-- /core JS for tables -->
        <script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.flash.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.print.min.js"></script>
        <!-- /core JS for tables -->

	<!-- footer-->
    <?php

require_once '../footer/footer.php';

?>
<!-- /Footer -->
</body>
</html>
