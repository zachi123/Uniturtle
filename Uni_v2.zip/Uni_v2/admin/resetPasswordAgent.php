<?php
        	include '../config/session.php';
            include '../config/db_con.php';


        //This code runs if the form has been submitted
        if (isset($_GET['id']))
            {
                    $id = $_GET['id'];

                    $sql = "SELECT * FROM `merchants` WHERE `agentID` = '$id'";
                            $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                            $row = $result->fetch_assoc();

                            function generateRandomString($length = 6) {
                                return substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length/strlen($x)) )),1,$length);
                            }
                            
                            $password =  generateRandomString();  // OR: generateRandomString(24)

                            $pass = md5($password); //encrypted version for database entry


                            $update = "UPDATE `merchants` SET `password`='$pass' WHERE `agentID`= '$id'";
                            $conn->query($update);


                            // Update the Audit taril table for this action by the user who has logged in//
								
                            $msg ="Password was reset successfully for Agent NRC: " . $row['agentNRC'] ." and mobile : ".  $row['mobile'] ." , New Password : " .$password;

                            date_default_timezone_set('Africa/Lusaka');

                            $userID					= $_SESSION['sess_userID'];
                            $ActionDate    		 	= date("Y-m-d h:i:sa");
                            $ActionDoneBy			= $_SESSION['sess_firstname']." ".$_SESSION['sess_lastname'];
                            $Action					= $msg;
                            
                            $log = "INSERT INTO `audit` (actionID, userID, actionDate, actionDoneBy, action)
                            VALUES ('','$userID','$ActionDate','$ActionDoneBy','$Action')";
                            $conn->query($log);


                            ///////////////////////////////////////SMS PART starts here//////////////////////////////////////////////////
        
                            $msg    = "Your password has been reset, your new password is : " . $password;
                            
                            $query = http_build_query([
                                'username' 	=> 'probase',
                                'password' 	=> 'probase',
                                'mobiles' 	=> 	$row['mobile'],
                                'message' 	=>	$msg,
                                'sender' 	=> 'UNITURTLE',
                                'type' 		=> 'TEXT'

                            ]);
                            
                            $url = "http://smsapi.probasesms.com/apis/text/index.php?".$query;
                            //var_dump($url);
                            
                            // Get cURL resource
                            $curl = curl_init();
                            // Set some options - we are passing in a useragent too here
                            curl_setopt_array($curl, array(
                                CURLOPT_RETURNTRANSFER => 1,
                                CURLOPT_URL => $url,
                                CURLOPT_USERAGENT => 'uniturtle'
                            ));
                            // Send the request & save response to $resp
                            $resp = curl_exec($curl);
                            // Close request to clear up some resources
                            curl_close($curl);
                            ///////////////////////////////////////SMS PART ends here//////////////////////////////////////////////////

                            ///////////////////////////////////////Email PART starts here//////////////////////////////////////////////////

                            $message 	= $msg;	
                            $to			= $row['email'];
                            $subject	= 'Uniturtle Industries';
                        

                            ini_set("SMTP", "smtp.gmail.com");
                            ini_set("sendmail_from","chiza@probasegroup.com");

                            $headers = "From: chiza@probasegroup.com"."\r\n";
                            $headers .= "cc: \r\n";
                            $headers .= 'MIME-Version: 1.0' . "\r\n";
                            $headers .= "Content-type: text/html; charset=iso-8859-1";
                            
                            mail( $to, $subject, $message, $headers);

                            ///////////////////////////////////////email PART ends here//////////////////////////////////////////////////
                            
                            echo "<script>window.open('agents.php?err=6','_self');</script>";

                        }else{
                            echo "<script>window.open('agents.php.php?err=7','_self');</script>";
                        }
                
            }

?>