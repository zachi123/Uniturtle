<?php
	require_once '../config/session.php';
  require_once '../config/db_con.php';
  require_once 'graph_data.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>

	<!-- Styles -->
		<style>
				#chartdiv {
				width: 100%;
        height: 320px;
        
        }		
        
		</style>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Uniturtle</title>

	<!-- Global stylesheets -->
	<link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
	<link href="../assets/css/icons/icomoon/styles.css" rel="stylesheet" type="text/css">
	<link href="../assets/css/bootstrap.css" rel="stylesheet" type="text/css">
	<link href="../assets/css/core.css" rel="stylesheet" type="text/css">
	<link href="../assets/css/components.css" rel="stylesheet" type="text/css">
	<link href="../assets/css/colors.css" rel="stylesheet" type="text/css">
	<!-- /global stylesheets -->

	<!-- Resources -->
<script src="../graph/amcharts.js"></script>
<script src="../graph/serial.js"></script>
<script src="../graph/export.min.js"></script>
<link rel="stylesheet" href="../graph/export.css" type="text/css">
<script src="../graph/light.js"></script>
<!-- Chart code -->

<script>
var chart = AmCharts.makeChart("chartdiv", {
  "type": "serial",
  "theme": "light",
  "dataDateFormat": "MM-YYYY",
  "precision": 2,
  "valueAxes": [{
    "id": "v1",
    "title": "Total Sales",
    "position": "left",
    "autoGridCount": false,
    "labelFunction": function(value) {
      return "K" + Math.round(value) + "";
    }
  }, {
    "id": "v2",
    "title": "Total Number of Transactions",
    "gridAlpha": 0,
    "position": "right",
    "autoGridCount": true
  }],
  "graphs": [ {
    "id": "g1",
    "valueAxis": "v2",
    "bullet": "round",
    "bulletBorderAlpha": 1,
    "bulletColor": "#FFFFFF",
    "bulletSize": 5,
    "hideBulletsCount": 50,
    "lineThickness": 2,
    "lineColor": "#f20c2a",
    "type": "smoothedLine",
    "title": "Miscellaneous Transactions",
    "useLineColorForBulletBorder": true,
    "valueField": "market1",
    "balloonText": "[[title]]<br /><b style='font-size: 130%'>K[[value]]</b>"
  }, {
    "id": "g2",
    "valueAxis": "v2",
    "bullet": "round",
    "bulletBorderAlpha": 1,
    "bulletColor": "#5f2bdb",
    "bulletSize": 5,
    "hideBulletsCount": 50,
    "lineThickness": 2,
    "lineColor": "#5f2bdb",
    "type": "smoothedLine",
    "dashLength": 5,
    "title": "Premiums Transactions",
    "useLineColorForBulletBorder": true,
    "valueField": "market2",
    "balloonText": "[[title]]<br /><b style='font-size: 130%'>K[[value]]</b>"
  }],
  "chartCursor": {
    "pan": true,
    "valueLineEnabled": true,
    "valueLineBalloonEnabled": true,
    "cursorAlpha": 0,
    "valueLineAlpha": 0.2
  },
  "categoryField": "date",
  "categoryAxis": {
    "parseDates": true,
    "dashLength": 1,
    "minorGridEnabled": true
  },
  "legend": {
    "useGraphSettings": true,
    "position": "top"
  },
  "balloon": {
    "borderThickness": 1,
    "shadowAlpha": 0
  },
  "dataProvider": [{
    "date": "<?php echo $month01 ;?>",
    "market1": "<?php echo $misc_month1;?>",
    "market2": "<?php echo $premium_month1;?>"
  }, {
    "date": "<?php echo $month02 ;?>",
    "market1": "<?php echo $misc_month2;?>",
    "market2": "<?php echo $premium_month2;?>"
  }, {
    "date": "<?php echo $month03 ;?>",
    "market1": "<?php echo $misc_month3;?>",
    "market2": "<?php echo $premium_month3;?>"
  }, {
    "date": "<?php echo $month04 ;?>",
    "market1": "<?php echo $misc_month4;?>",
    "market2": "<?php echo $premium_month4;?>"
  }, {
    "date": "<?php echo $month05 ;?>",
    "market1": "<?php echo $misc_month5;?>",
    "market2": "<?php echo $premium_month5;?>"
  }, {
    "date": "<?php echo $month06 ;?>",
    "market1": "<?php echo $misc_month6;?>",
    "market2": "<?php echo $premium_month6;?>"
  }, {
    "date": "<?php echo $month07 ;?>",
    "market1": "<?php echo $misc_month7;?>",
    "market2": "<?php echo $premium_month7;?>"
  }, {
    "date": "<?php echo $month08 ;?>",
    "market1": "<?php echo $misc_month8;?>",
    "market2": "<?php echo $premium_month8;?>"
  }, {
    "date": "<?php echo $month09 ;?>",
    "market1": "<?php echo $misc_month9;?>",
    "market2": "<?php echo $premium_month9;?>"
  }, {
    "date": "<?php echo $month10 ;?>",
    "market1": "<?php echo $misc_month10;?>",
    "market2": "<?php echo $premium_month10;?>"
  }, {
    "date": "<?php echo $month11 ;?>",
    "market1": "<?php echo $misc_month11;?>",
    "market2": "<?php echo $premium_month11;?>"
  }, {
    "date": "<?php echo $month12 ;?>",
    "market1": "<?php echo $misc_month12;?>",
    "market2": "<?php echo $premium_month12;?>"
  }]
});
</script>


	<!-- Core JS files -->
	<script type="text/javascript" src="../assets/js/plugins/loaders/pace.min.js"></script>
	<script type="text/javascript" src="../assets/js/core/libraries/jquery.min.js"></script>
	<script type="text/javascript" src="../assets/js/core/libraries/bootstrap.min.js"></script>
	<script type="text/javascript" src="../assets/js/plugins/loaders/blockui.min.js"></script>
	<!-- /core JS files -->

	<!-- Theme JS files -->
	<script type="text/javascript" src="../assets/js/plugins/visualization/d3/d3.min.js"></script>
	<script type="text/javascript" src="../assets/js/plugins/visualization/d3/d3_tooltip.js"></script>
	<script type="text/javascript" src="../assets/js/plugins/forms/styling/switchery.min.js"></script>
	<script type="text/javascript" src="../assets/js/plugins/forms/styling/uniform.min.js"></script>
	<script type="text/javascript" src="../assets/js/plugins/forms/selects/bootstrap_multiselect.js"></script>
	<script type="text/javascript" src="../assets/js/plugins/ui/moment/moment.min.js"></script>
	<script type="text/javascript" src="../assets/js/plugins/pickers/daterangepicker.js"></script>

	<script type="text/javascript" src="../assets/js/core/app.js"></script>
	<script type="text/javascript" src="../assets/js/pages/dashboard_boxed.js"></script>

	<script type="text/javascript" src="../assets/js/plugins/ui/ripple.min.js"></script>
	<!-- /theme JS files -->

</head>

<body id="background" class="layout-boxed navbar-bottom backpic">

	<!-- Main navbar AND Main menu-->
  <?php

    require_once '../Menu/menu_admin.php';

?>
	<!-- /page header -->


	<!-- Page container -->
	<div class="page-container">
		<!-- Page content -->
		<div class="page-content" id="Div1">
			<!-- Main content -->
			<div class="content-wrapper">
				<!-- Traffic sources -->
				<div class="panel panel-flat">
					<div class="panel-heading">
						<h6 class="panel-title">Transactions Statistics</h6>
					</div>
					<div class="container-fluid" style="margin-top:5px;">
						<div class="row">
							<div class="col-lg-6">
								<ul class="list-inline text-center">
									<li>
										<a href="#" class="btn border-warning-400 text-warning-400 btn-flat btn-rounded btn-icon btn-xs valign-text-bottom"><i class=""><?php echo $row1['PremiumsTransactions'];?></i></a>
									</li>
									<li class="text-left">
											<div class="text-semibold">Premiums Transactions</div>
											<div class="text-muted top-1"><span class="status-mark border-success position-left"></span>Value  K<?php echo $sum;?> </div>
									</li>
								</ul>
								<div class="col-lg-10 col-lg-offset-1">
									<div class="content-group" id="new-sessions"></div>
								</div>
							</div>
							<div class="col-lg-6">
								<ul class="list-inline text-center">
									<li>
										<a href="#" class="btn border-indigo-400 text-indigo-400 btn-flat btn-rounded btn-icon btn-xs valign-text-bottom"><i class=""><?php echo $row2['MiscellaneousTransactions'];?></i></a>
									</li>
									<li class="text-left">
										<div class="text-semibold">Miscellaneous Transactions</div>
										<div class="text-muted top-1"><span class="status-mark border-success position-left"></span>Value  K<?php echo $sum1;?> </div>
									</li>
								</ul>
								<div class="col-lg-10 col-lg-offset-1">
									<div class="content-group" id="total-online"></div>
								</div>
							</div>
						</div>
					</div>

					<div id="chartdiv"></div>
				</div>
				<!-- /traffic sources -->

			</div>
			<!-- /content area -->
		</div>
    <!-- /page content -->
    
<!-- /page content At the bottom is the div for failed transactions-->

 <!-- Page content -->
 <div class="page-content" id="Div2">
  <!-- Main content -->
  <div class="content-wrapper">
    <!-- Traffic sources -->
    <div class="panel panel-flat">
      <div class="panel-heading">
        <h6 class="panel-title">All Failed Transactions Statistics</h6>
        <div class="heading-elements">
          <form class="heading-form" action="#">
            <div class="form-group">
                <button type="button" class="btn btn-danger btn-xs" onclick="switchVisible();" style="height:20px;line-height:7px;">Click to view Successful Statistics</button>
                <input id="Button1" class="btn btn-danger btn-xs"  style="height:20px;line-height:7px;" type="button" value="Click to view Successful Statistics" onclick="switchVisible();"/>
            </div>
          </form>
        </div>
      </div>
      <div class="container-fluid" style="margin-top:20px;">
        <div class="row">
        <div class="col-lg-3">
            <ul class="list-inline text-center">
              <li>
                <a href="#" class="btn border-teal text-teal btn-flat btn-rounded btn-icon btn-xs valign-text-bottom"><i class="icon-mobile"></i></a>
              </li>
              <li class="text-left">
                  <div class="text-semibold">Talk Time</div>
                  <div class="text-muted top-1"><span class="status-mark border-success position-left"></span> Success(10)  K5,378</div>
              </li>
            </ul>

            <div class="col-lg-10 col-lg-offset-1">
              <div class="content-group" id="new-visitors"></div>
            </div>
          </div>
          <div class="col-lg-3">
            <ul class="list-inline text-center">
              <li>
                <a href="#" class="btn border-teal text-teal btn-flat btn-rounded btn-icon btn-xs valign-text-bottom"><i class="icon-power-cord"></i></a>
              </li>
              <li class="text-left">
                  <div class="text-semibold">Electricity</div>
                  <div class="text-muted top-1"><span class="status-mark border-success position-left"></span> Success(10)  K5,378</div>
              </li>
            </ul>
            <div class="col-lg-10 col-lg-offset-1">
              <div class="content-group" id="new-visitors"></div>
            </div>
          </div>
          <div class="col-lg-3">
            <ul class="list-inline text-center">
              <li>
                <a href="#" class="btn border-warning-400 text-warning-400 btn-flat btn-rounded btn-icon btn-xs valign-text-bottom"><i class="icon-tv"></i></a>
              </li>
              <li class="text-left">
                  <div class="text-semibold">TV Subscription</div>
                  <div class="text-muted top-1"><span class="status-mark border-success position-left"></span> Success(10)  K5,378</div>
              </li>
            </ul>
            <div class="col-lg-10 col-lg-offset-1">
              <div class="content-group" id="new-sessions"></div>
            </div>
          </div>
          <div class="col-lg-3">
            <ul class="list-inline text-center">
              <li>
                <a href="#" class="btn border-indigo-400 text-indigo-400 btn-flat btn-rounded btn-icon btn-xs valign-text-bottom"><i class="icon-bars-alt"></i></a>
              </li>
              <li class="text-left">
                <div class="text-semibold">Data Bundles</div>
                <div class="text-muted top-1"><span class="status-mark border-success position-left"></span>Success(10)  K5,378 </div>
              </li>
            </ul>
            <div class="col-lg-10 col-lg-offset-1">
              <div class="content-group" id="total-online"></div>
            </div>
          </div>
        </div>
      </div>
      
      <div id="chartdiv" class="ScrollStyle"></div>
    </div>
    <!-- /traffic sources -->

  </div>
  <!-- /content area -->
</div>
<!-- /page content -->

	</div>
	<!-- /page container -->


	<!-- footer-->
  <?php

      require_once '../footer/footer.php';

  ?>
	<!-- /Footer -->

</body>
</html>
