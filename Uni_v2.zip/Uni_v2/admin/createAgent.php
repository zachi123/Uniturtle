<?php    

		include '../config/session.php';
		include '../config/db_con.php';
      
		if(isset($_POST["submit"])){
								  $fname				= ucfirst($_POST["fname"]);
								  $lname				= ucfirst($_POST["lname"]);
								  $userName				= $_POST["username"];								  					 
								  $nRc					= $_POST["nrc"];								  					 
								  $terminaid			= $_POST["terminalid"];
								  $mobile				= $_POST["mobile"];
								  $email				= $_POST["email"];
								  $password1     		= $_POST["pass"];
								  $status				= $_POST["status"];							 
								  $date					= $_POST["date"];							 
                				  $password     		= md5($_POST["pass"]);
								  $names				= $fname ." ".$lname;
									
							$chkcol = "SELECT `username` FROM `merchants` WHERE `username`='$userName'";
							$result = $conn->query($chkcol);
							$row2 	= $result->fetch_assoc();
							
							if(isset($row2['username'])) {
								
								 echo "<script>window.open('agents.php?err=3','_self');</script>";
								
							}else{
								
								$sql = "INSERT INTO merchants (agentID, agentNRC, terminalID, userName, firstName, lastName,email, mobile, created_at, password, status)
								VALUES ('','$nRc','$terminaid','$userName','$fname','$lname','$email','$mobile','$date','$password','$status')";

								$conn->query($sql);
								
								// Update the Audit taril table for this action by the user who has logged in//
								
									$msg ="Created a new Agent account on the system with details : " . $names ." , ". $userName ."," .$terminaid.",". $mobile.",". $email.",". $status;
									$userID					= $_SESSION['sess_userID'];
								    $ActionDate    		 	= date("Y-m-d h:i:sa");
									$ActionDoneBy			= $_SESSION['sess_firstname']." ".$_SESSION['sess_lastname'];
									$Action					= $msg;
									
									$log = "INSERT INTO `audit` (actionID, userID, actionDate, actionDoneBy, action)
									VALUES ('','$userID','$ActionDate','$ActionDoneBy','$Action')";
								    $conn->query($log);
								
///////////////////////////////////////SMS PART//////////////////////////////////////////////////

        
		$msg    = "Dear"." ". $fname ." your account has been created on the Uniturtle system, your Username : " . $userName . " and Password". $_POST["pass"];
		
	    $query = http_build_query([
			'username' 	=> 'probase',
			'password' 	=> 'probase',
			'mobiles' 	=> 	$mobile,
			'message' 	=>	$msg,
			'sender' 	=> 'UNITURTLE',
			'type' 		=> 'TEXT'
		]);
		
		$url = "http://smsapi.probasesms.com/apis/text/index.php?".$query;
		//var_dump($url);
		
		// Get cURL resource
		$curl = curl_init();
		// Set some options - we are passing in a useragent too here
		curl_setopt_array($curl, array(
			CURLOPT_RETURNTRANSFER => 1,
			CURLOPT_URL => $url,
			CURLOPT_USERAGENT => 'uniturtle'
		));
		// Send the request & save response to $resp
		$resp = curl_exec($curl);
		// Close request to clear up some resources
		curl_close($curl);
		
		
////////////////////////////////////////EMAIL PART//////////////////////////////////////////////////////////////////////////////////////////
           $today = date('d/m/Y');
			$body="<html>";
			$body.="<body>";
			$body.="<section class='invoice' style='width:900px;min-height:300px;border:1px solid orange;margin:auto; padding:10px;'>";
			$body.="<!-- title row -->";
			$body.="<div class='row' style='border-bottom:1px solid black;padding-bottom:-10px;'>";
			$body.="<div class='col-xs-12'>";
			$body.="<h3 class='page-header' style='color:orange;'>";
			$body.="<i class='fa fa-globe'></i> test";
			$body.="<small class='pull-right' style='float:right;font-size:12px;color:black;'>"." "."Date:"."".$today .""."</small>";
			$body.="</h3>";
			$body.="</div>";
			$body.="<!-- /.col -->";
			$body.="</div>";
			$body.="<!-- info row -->";
			//////////////////////////////////FROM DETAILS////////////////////////
			$body.="<div class='row invoice-info' style='min-height:120px;margin-top:20px;'>";
			$body.="<div class='col-sm-4 invoice-col' style='float:left;font-size:11px;'>";
			$body.="From";
			$body.="<address style='font-size:11px;line-height: 1.42857143;'>";
			$body.="<b>Uniturtle Industries.</b><br>";
			$body.="xxxxxxxxxxxxxxxxx<br>";
			$body.="XXXXXXXXXXXXXXXXXX<br>";
			$body.="XXXXXXXXXXXXXXXXXX<br>";
			$body.="Email: XXXXXXXXXXXXXXXXXX";
			$body.="</address>";
			$body.="</div>";
			$body.="<!-- /.col -->";
			/////////////////////////LOGIN DETAILS////////////////////////
			$body.="<div  style='float:right;margin-right:20px;font-size:11px;line-height: 1.42857143;'>";
			$body.="<i>Login Details</i><br>";
			$body.="<i>UserId :"."". $userName ."". "<br>";
			$body.="<i>Password:</i>"." ".$_POST["pass"];
			$body.="</div>";
			$body.="<!-- /.col -->";
			$body.="<!-- /.col -->";
			////////////////////////TO DETAILS//////////////////////////////
			$body.="<div class=' invoice-col' style='float:left;margin-left:150px;font-size:11px;'>";
			$body.="To";
			$body.="<address style='font-size:11px;line-height: 1.42857143;'>";
			$body.="<strong>"."". $fname." ".$lname." "."</strong><br>";
			$body.="Status :"."". $status .""."<br>";
			$body.="Email  :"."". $email."". "<br>";
			$body.="</address>";
			$body.="</div>";
			$body.="</div>";
			//////////////////////////FOOTER DEATILS///////////////
			$body.="<div class='row' >";
			$body.="<!-- accepted payments column -->";
			$body.="<div class='col-xs-6' style='margin-top:20px;'>";
			$body.="<img src=\"dist/img/nice.png\" alt=\"Uniturtle Industries\" style='width:100px;'>";
			$body.="<p class='text-mute' style='margin-top:10px;width:700px;font-size:10px;padding:10px;background-color: #f5f5f5;border:1px solid orange;font-family:Sans Pro,Helvetica Neue,Helvetica,Arial,sans-serif;border-radius:4px;line-height: 1.42857143;'>
			You have been added on the system
			</p>";
			$body.="</div>";
			$body.="</div>";
			$body.="</section>";
			$body.="</body>";
			$body.="</html>";


						$message 	= $body;	
                        $to			= $email;
						$subject	= 'Uniturtle Industries';
					

						ini_set("SMTP", "smtp.gmail.com");
						ini_set("sendmail_from","chiza@probasegroup.com");

						$headers = "From: chiza@probasegroup.com"."\r\n";
						$headers .= "cc: \r\n";
						$headers .= 'MIME-Version: 1.0' . "\r\n";
                        $headers .= "Content-type: text/html; charset=iso-8859-1";
						

						mail( $to, $subject, $message, $headers);
						//echo "Check your email now....<BR/>";
							//this redirects to the all users page	   
							echo "<script>window.open('agents.php?err=1','_self');</script>";
									
										//header("location:users.php?st=2");	

      }	
	}
									
							
							
?>	 