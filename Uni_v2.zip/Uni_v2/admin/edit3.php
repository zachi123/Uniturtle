<?php  include '../config/session.php';?>
<?php include '../config/db_con.php';?>
 
 <?php            
							  if(isset($_POST["insert"])){
									$id 			= $_POST['client_id'];
									$Names			= ucwords($_POST["names"]);
									$NRC			= $_POST["nrc"];
									$Mobile			= $_POST["mobile"];
									$status			= $_POST["status"];
									$gender			= $_POST["gender"];
									$dob			= $_POST["dob"];
									$premiumType	= $_POST["premiumType"];
									$policyNumber	= $_POST["policyNumber"];
								  
								  $result = $conn->query("SELECT* FROM `clients` WHERE `policyNumber` = '$policyNumber' AND `clientID` !== '$id'");
				   
								  if($result->num_rows == 0) { 
								  
									$update = "UPDATE `clients` SET 
									`clientName`			='$Names',
									`mobile`				='$Mobile',
									`NRC`					='$NRC',
									`status`				='$status',
									`patch`					='O',
									`gender`				='$gender',
									`dateOfbirth`			='$dob',
									`primiumType`			='$premiumType'
									
									 WHERE `clientID`=$id";
				   
		                              $conn->query($update);
									    echo "<script>window.open('clients.php?err=5','_self');</script>";
	 
								}else{

										echo "<script>window.open('clients.php?err=11','_self');</script>";
							}
						}
 
										
							
							
?>	 