<?php
    require_once '../config/session.php';
    require_once '../config/db_con.php';

    if(isset($_POST["client_id"])){

            $query = "SELECT* FROM `clients` WHERE `clientID` ='".$_POST["client_id"]."'";
            $result = mysqli_query($conn, $query);
            $row = mysqli_fetch_array($result);
            echo json_encode($row);

    }

?>