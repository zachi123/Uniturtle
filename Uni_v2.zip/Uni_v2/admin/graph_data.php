<?php

$year   =date('Y');

//MONTHS OF A ONE COMPLETE YEAR//
$month01    = '01'."-".$year; 
$month02    = '02'."-".$year; 
$month03    = '03'."-".$year; 
$month04    = '04'."-".$year; 
$month05    = '05'."-".$year; 
$month06    = '06'."-".$year; 
$month07    = '07'."-".$year; 
$month08    = '08'."-".$year; 
$month09    = '09'."-".$year; 
$month10    = '10'."-".$year; 
$month11    = '11'."-".$year; 
$month12    = '12'."-".$year; 

//COUNT OF ALL TRANSACTIONS STARTS HERE//
$sqlSum = "SELECT count(*) AS PremiumsTransactions FROM `transactions` WHERE `transactionType` ='premiums' AND `year` = '$year'";
$result = $conn->query($sqlSum);
$row1 = $result->fetch_assoc();


$sqlSum = "SELECT count(*) AS MiscellaneousTransactions FROM `transactions` WHERE `transactionType` ='misc' AND `year` = '$year'";
$result = $conn->query($sqlSum);
$row2 = $result->fetch_assoc();
//COUNT OF ALL TRANSACTIONS ENDS HERE//


//SUM FOR THE ALL YEAR STARTS HERE//
$res = mysqli_query($conn,"SELECT sum(amount) FROM `transactions` WHERE `transactionType`='premiums' AND `year`= '$year'");
if (FALSE === $res) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res);
$sum = $row[0];

$res = mysqli_query($conn,"SELECT sum(amount) FROM `transactions` WHERE `transactionType`='misc' AND `year`= '$year'");
if (FALSE === $res) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res);
$sum1 = $row[0];
//SUM FOR THE ALL YEAR ENDS HERE//

//PREMIUM PAYMENTS FOR EACH MONTH//
$res = mysqli_query($conn,"SELECT sum(amount) FROM `transactions` WHERE `transactionType`='premiums' AND `year`= '$year' AND `month`='01'");
if (FALSE === $res) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res);
$premium_month1 = $row[0];

$res = mysqli_query($conn,"SELECT sum(amount) FROM `transactions` WHERE `transactionType`='premiums' AND `year`= '$year' AND `month`='02'");
if (FALSE === $res) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res);
$premium_month2 = $row[0];

$res = mysqli_query($conn,"SELECT sum(amount) FROM `transactions` WHERE `transactionType`='premiums' AND `year`= '$year' AND `month`='03'");
if (FALSE === $res) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res);
$premium_month3 = $row[0];

$res = mysqli_query($conn,"SELECT sum(amount) FROM `transactions` WHERE `transactionType`='premiums' AND `year`= '$year' AND `month`='04'");
if (FALSE === $res) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res);
$premium_month4 = $row[0];

$res = mysqli_query($conn,"SELECT sum(amount) FROM `transactions` WHERE `transactionType`='premiums' AND `year`= '$year' AND `month`='05'");
if (FALSE === $res) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res);
$premium_month5 = $row[0];

$res = mysqli_query($conn,"SELECT sum(amount) FROM `transactions` WHERE `transactionType`='premiums' AND `year`= '$year' AND `month`='06'");
if (FALSE === $res) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res);
$premium_month6 = $row[0];

$res = mysqli_query($conn,"SELECT sum(amount) FROM `transactions` WHERE `transactionType`='premiums' AND `year`= '$year' AND `month`='07'");
if (FALSE === $res) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res);
$premium_month7 = $row[0];

$res = mysqli_query($conn,"SELECT sum(amount) FROM `transactions` WHERE `transactionType`='premiums' AND `year`= '$year' AND `month`='08'");
if (FALSE === $res) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res);
$premium_month8 = $row[0];

$res = mysqli_query($conn,"SELECT sum(amount) FROM `transactions` WHERE `transactionType`='premiums' AND `year`= '$year' AND `month`='09'");
if (FALSE === $res) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res);
$premium_month9 = $row[0];

$res = mysqli_query($conn,"SELECT sum(amount) FROM `transactions` WHERE `transactionType`='premiums' AND `year`= '$year' AND `month`='10'");
if (FALSE === $res) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res);
$premium_month10 = $row[0];

$res = mysqli_query($conn,"SELECT sum(amount) FROM `transactions` WHERE `transactionType`='premiums' AND `year`= '$year' AND `month`='11'");
if (FALSE === $res) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res);
$premium_month11 = $row[0];

$res = mysqli_query($conn,"SELECT sum(amount) FROM `transactions` WHERE `transactionType`='premiums' AND `year`= '$year' AND `month`='12'");
if (FALSE === $res) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res);
$premium_month12 = $row[0];
//PREMIUM PAYMENTS FOR EACH MONTH ENDS HERE//


//MISC PAYMENTS FOR EACH MONTH STARTS HERE//

$res = mysqli_query($conn,"SELECT sum(amount) FROM `transactions` WHERE `transactionType`='misc' AND `year`= '$year' AND `month`='01'");
if (FALSE === $res) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res);
$misc_month1 = $row[0];

$res = mysqli_query($conn,"SELECT sum(amount) FROM `transactions` WHERE `transactionType`='misc' AND `year`= '$year' AND `month`='02'");
if (FALSE === $res) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res);
$misc_month2 = $row[0];

$res = mysqli_query($conn,"SELECT sum(amount) FROM `transactions` WHERE `transactionType`='misc' AND `year`= '$year' AND `month`='03'");
if (FALSE === $res) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res);
$misc_month3 = $row[0];

$res = mysqli_query($conn,"SELECT sum(amount) FROM `transactions` WHERE `transactionType`='misc' AND `year`= '$year' AND `month`='04'");
if (FALSE === $res) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res);
$misc_month4 = $row[0];

$res = mysqli_query($conn,"SELECT sum(amount) FROM `transactions` WHERE `transactionType`='misc' AND `year`= '$year' AND `month`='05'");
if (FALSE === $res) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res);
$misc_month5 = $row[0];

$res = mysqli_query($conn,"SELECT sum(amount) FROM `transactions` WHERE `transactionType`='misc' AND `year`= '$year' AND `month`='06'");
if (FALSE === $res) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res);
$misc_month6 = $row[0];

$res = mysqli_query($conn,"SELECT sum(amount) FROM `transactions` WHERE `transactionType`='misc' AND `year`= '$year' AND `month`='07'");
if (FALSE === $res) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res);
$misc_month7 = $row[0];

$res = mysqli_query($conn,"SELECT sum(amount) FROM `transactions` WHERE `transactionType`='misc' AND `year`= '$year' AND `month`='08'");
if (FALSE === $res) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res);
$misc_month8 = $row[0];

$res = mysqli_query($conn,"SELECT sum(amount) FROM `transactions` WHERE `transactionType`='misc' AND `year`= '$year' AND `month`='09'");
if (FALSE === $res) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res);
$misc_month9 = $row[0];

$res = mysqli_query($conn,"SELECT sum(amount) FROM `transactions` WHERE `transactionType`='misc' AND `year`= '$year' AND `month`='10'");
if (FALSE === $res) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res);
$misc_month10 = $row[0];

$res = mysqli_query($conn,"SELECT sum(amount) FROM `transactions` WHERE `transactionType`='misc' AND `year`= '$year' AND `month`='11'");
if (FALSE === $res) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res);
$misc_month11 = $row[0];

$res = mysqli_query($conn,"SELECT sum(amount) FROM `transactions` WHERE `transactionType`='misc' AND `year`= '$year' AND `month`='12'");
if (FALSE === $res) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res);
$misc_month12 = $row[0];

//MISC PAYMENTS FOR EACH MONTH ENDS HERE//
?>