<?php  include '../config/session.php';?>
<?php include '../config/db_con.php';?>
 
 <?php            
							  if(isset($_POST["submit"])){
								  $pCode				= $_POST["codet"];
								  $pName				= $_POST["name"];
								  $cover				= $_POST["cover_amount"];
								  $pAmount				= $_POST["amount"];
								  $pDate   		 		= date("Y-m-d h:i:sa");
								  $pStatus   		 	= 'Active';
								  
		   
							  $result = $conn->query("SELECT `premCode` FROM `premiums` WHERE `premCode` = '$pCode'");
                              if($result->num_rows == 0) {
								  
									$sql = "INSERT INTO `premiums` (premID, premCode, premName, premiun_cover, premAmount, date, status)
									VALUES ('','$pCode','$pName', '$cover', '$pAmount','$pDate','$pStatus')";
								    $conn->query($sql);
									
									
									$msg ="Added a new premium to the list on this system with details : " . $pCode ." , ". $pName .", " . $pAmount .", ". $pStatus.", ". $cover;
								
									// Update the Audit taril table for this action by the user who has logged in//
											$userID					= $_SESSION['sess_userID'];
											$ActionDate    		 	= date("Y-m-d h:i:sa");
											$ActionDoneBy			= $_SESSION['sess_firstname']." ".$_SESSION['sess_lastname'];
											$Action					= $msg;
											
											$log = "INSERT INTO `audit` (actionID, userID, actionDate, actionDoneBy, action)
											VALUES ('','$userID','$ActionDate','$ActionDoneBy','$Action')";
											$conn->query($log);
									
									//this redirects to the all users page	   
									echo "<script>window.open('premiums.php?err=3','_self');</script>";
			 
								} else {

         							echo "<script>window.open('premiums.php?err=2','_self');</script>";
								}	
								  
							

}										
							
?>	 