<?php
	require_once '../config/session.php';
    require_once '../config/db_con.php';
	
	
	if(isset($_GET["id"])){
	   $id = $_GET["id"];
	  
	}
	
	
	
	///QUERY PULL AGENTS DETAILS
	$sql  = "SELECT* FROM merchants WHERE AgentID=$id";
	$result = mysqli_query($conn, $sql);
	$row1 = mysqli_fetch_assoc($result);
	
	
	$sqlSum = "SELECT SUM(AmountCredit) AS value_sum FROM value WHERE AgentID ='$id'";
	$result = $conn->query($sqlSum);
	$row3 = $result->fetch_assoc();
							
					
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Uniturtle</title>

<!-- Global stylesheets -->
<link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
<link href="../assets/css/icons/icomoon/styles.css" rel="stylesheet" type="text/css">
<link href="../assets/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="../assets/css/core.css" rel="stylesheet" type="text/css">
<link href="../assets/css/components.css" rel="stylesheet" type="text/css">
<link href="../assets/css/colors.css" rel="stylesheet" type="text/css">
<!-- /global stylesheets -->


<!-- Global for the table -->
<link href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css">
<link href="https://cdn.datatables.net/buttons/1.5.2/css/buttons.dataTables.min.css" rel="stylesheet" type="text/css">
<!-- Global for the table -->

<!-- Core JS files -->
<script type="text/javascript" src="../assets/js/plugins/loaders/pace.min.js"></script>
<script type="text/javascript" src="../assets/js/core/libraries/jquery.min.js"></script>
<script type="text/javascript" src="../assets/js/core/libraries/bootstrap.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/loaders/blockui.min.js"></script>
<!-- /core JS files -->

<script type="text/javascript" src="../assets/js/plugins/notifications/jgrowl.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/ui/moment/moment.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/daterangepicker.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/anytime.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/picker.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/picker.date.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/picker.time.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/legacy.js"></script>

<script type="text/javascript" src="../assets/js/core/app.js"></script>
<script type="text/javascript" src="../assets/js/pages/picker_date.js"></script>

<script type="text/javascript" src="../assets/js/plugins/ui/ripple.min.js"></script>

<!-- Theme JS files -->
<script type="text/javascript" src="../assets/js/core/libraries/jquery_ui/interactions.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/forms/selects/select2.min.js"></script>

<script type="text/javascript" src="../assets/js/core/app.js"></script>
<script type="text/javascript" src="../assets/js/pages/form_select2.js"></script>

<script type="text/javascript" src="../assets/js/plugins/ui/ripple.min.js"></script>

</head>

<body id="background" class="layout-boxed navbar-bottom backpic">

	<!-- Main navbar AND Main menu-->
    <?php

			require_once '../Menu/menu_admin.php';

    ?>
    <!-- /page header -->


	<!-- Page container -->
	<div class="page-container">
		<!-- Page content -->
		<div class="page-content" id="Div1">
			<!-- Main content -->
			<div class="content-wrapper">
				<!-- Traffic sources -->
				<div class="panel panel-flat">
					<div class="panel-heading">
						<h6 class="panel-title">Agents Management</h6>
					</div>
					<div class="container-fluid" style="margin-top:5px;">
						<div class="row">
						<div class="col-lg-3">
								<ul class="list-inline text-center">
									<li>
										<a href="#" class="btn border-teal text-teal btn-flat btn-rounded btn-icon btn-xs valign-text-bottom"><i class=" icon-cash3"></i></a>
									</li>
									<li class="text-left">
											<div class="text-semibold">Total Load Value</div>
											<div class="text-muted top-1"><span class="status-mark border-success position-left"></span>K <?php echo $row3['value_sum'];?></div>
									</li>
								</ul>

								<div class="col-lg-10 col-lg-offset-1">
									<div class="content-group" id="new-visitors"></div>
								</div>
							</div>
							<div class="col-lg-3">
								<ul class="list-inline text-center">
									<li>
										<a href="#" class="btn border-teal text-teal btn-flat btn-rounded btn-icon btn-xs valign-text-bottom"><i class="icon-user"></i></a>
									</li>
									<li class="text-left">
											<div class="text-semibold">Account Name </div>
											<div class="text-muted top-1"><span class="status-mark border-success position-left"></span><?php echo $row1["firstName"]." ".$row1["lastName"];?></div>
									</li>
								</ul>
								<div class="col-lg-10 col-lg-offset-1">
									<div class="content-group" id="new-visitors"></div>
								</div>
							</div>
							<div class="col-lg-3">
								<ul class="list-inline text-center">
									<li>
										<a href="#" class="btn border-warning-400 text-warning-400 btn-flat btn-rounded btn-icon btn-xs valign-text-bottom"><i class="icon-coins"></i></a>
									</li>
									<li class="text-left">
											<div class="text-semibold">Available Balance</div>
											<div class="text-muted top-1"><span class="status-mark border-success position-left"></span> K <?php echo $row1["AvailableBalance"];?></div>
									</li>
								</ul>
								<div class="col-lg-10 col-lg-offset-1">
									<div class="content-group" id="new-sessions"></div>
								</div>
							</div>
							<div class="col-lg-3">
								<ul class="list-inline text-center">
									<li>
                                        <a href="#" class="btn border-indigo-400 text-indigo-400 btn-flat btn-rounded btn-icon btn-xs valign-text-bottom" data-toggle="modal" data-target="#myModal"><i class="icon-plus3"></i></a>
									</li>
									<li class="text-left">
										<div class="text-semibold">Load Value</div>
										<div class="text-muted top-1"><span class="status-mar border-success position-left"></span></div>
									</li>
								</ul>
								<div class="col-lg-10 col-lg-offset-1">
									<div class="content-group" id="total-online"></div>
								</div>
							</div>
						</div>
					</div>
                    <hr>
                    <div id="reportsTable" style="width:98%;margin:auto;">
                     <table id="example" class="display" style="width:100%;font-size:10px;">
                         <thead>
                             <tr>
                                 <th>Date Loaded</th>
                                 <th>Loaded By</th>
                                 <th>Amounts</th>
                                 <th>Transaction Ref</th>
                             </tr>
                         </thead>
                         <tbody>
						 <?php	
									$sql  = "SELECT* FROM value WHERE AgentID=$id";
									$result = mysqli_query($conn, $sql);

									if (mysqli_num_rows($result) > 0) {
										// output data of each row
										while($row = mysqli_fetch_assoc($result)) {
								echo "<tr class='odd gradeX'>
											<td>{$row["date"]}</td>
											<td>{$row["loadedBy"]}</td>
											<td>{$row["AmountCredit"]}</td>
											<td>{$row["transactionRef"]}</td>
									</tr>";
										}
									}
								?>
                         </tbody>
                     </table>
                   </div>
				</div>
                <!-- /traffic sources -->
                <!-- Modal content number1 starts here-->
                <div class="modal fade" id="myModal" role="dialog">
                        <div class="modal-dialog">
                        <!-- Modal content-->
                        <div class="modal-content">
                            <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title">Loading Value</h4>
                            </div>
                            <div class="modal-body">
                            <form class="form-horizontal"  action="addValue.php" method="POST">
                                <fieldset class="content-group">
                                    <legend class="text-bold" style="font-size:10px;color:red;"><i>The value you enter will be added to the available balance.*</i></legend>

                                    <div class="form-group client1">
                                        <label class="control-label col-lg-4" style="text-align:right;">Enter Amount</label>
                                        <div class="col-lg-6">
                                            <div class="input-group input-group-xlg">
                                                <span class="input-group-addon"></span>
                                                <input type="number" class="form-control" placeholder="Enter Amount" name="amount" required autocomplete="off">
												<input type ="hidden" value="<?php echo date('d-m-y : h:i:s');?>" name="date">
												<input type ="hidden" value="<?php echo $_SESSION['sess_firstname']." ".$_SESSION['sess_lastname'];?>" name="loader">
												<input type ="hidden" value="<?php echo 'FL'. date('dmy') . (rand(10,100));?>" name="RefNumber">
												<input type ="hidden" value="<?php echo $row1['agentID'];?>" name='AgentID'>
												<input type ="hidden" value="<?php echo $row1['terminalID'];?>" name='teminalID'>
                                            </div>
                                        </div>
                                    </div>
                                </fieldset>
                                <div class="btn-group btn-group-xs" style="margin-left:50px;"> 
                                    <button type="submit" class="btn btn-success" style="height:24px;line-height:4px;">Load Value</button>
                                </div>
                            </form>
                            </div>
                        </div>
                        </div>
                    </div>


            </div>
            <!-- /content area -->
        </div>
            <!-- /page content -->
    </div>
	<!-- /page container -->
    <script>	
            $(document).ready(function() {
                $('#example').DataTable( {
                    dom: 'Bfrtip',
                    buttons: [
                        'copy', 'csv', 'excel', 'pdf', 'print'
                    ]
                } );
            } );
    </script>
    
        <!-- /core JS for tables -->
        <script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.flash.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.print.min.js"></script>
        <!-- /core JS for tables -->

	<!-- footer-->
	<?php

require_once '../footer/footer.php';

?>
<!-- /Footer -->
</body>
</html>
