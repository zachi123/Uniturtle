<?php
    require_once '../config/session.php';
    require_once '../config/db_con.php';


     	///QUERY PULL AGENTS DETAILS
	$sqlSum = "SELECT count(*) AS active FROM `merchants` WHERE `status` ='Active'";
	$result = $conn->query($sqlSum);
    $row1 = $result->fetch_assoc();

    $sqlSum = "SELECT count(*) AS yonse FROM `merchants`";
	$result = $conn->query($sqlSum);
    $row2 = $result->fetch_assoc();

    $sqlSum = "SELECT count(*) AS bamapulobuleme FROM `merchants` WHERE `status` ='Declined'";
	$result = $conn->query($sqlSum);
    $row3 = $result->fetch_assoc();

    $sqlSum = "SELECT count(*) AS bantota FROM `merchants` WHERE `status` ='Disabled'";
	$result = $conn->query($sqlSum);
    $row4 = $result->fetch_assoc();

    $sqlSum = "SELECT count(*) AS bamoyo FROM `merchants` WHERE `status` ='Pending'";
	$result = $conn->query($sqlSum);
    $row5 = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Uniturtle</title>

<!-- Global stylesheets -->
<link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
<link href="../assets/css/icons/icomoon/styles.css" rel="stylesheet" type="text/css">
<link href="../assets/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="../assets/css/core.css" rel="stylesheet" type="text/css">
<link href="../assets/css/components.css" rel="stylesheet" type="text/css">
<link href="../assets/css/colors.css" rel="stylesheet" type="text/css">
<!-- /global stylesheets -->

<!-- Global for the table -->
<link href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css">
<link href="https://cdn.datatables.net/buttons/1.5.2/css/buttons.dataTables.min.css" rel="stylesheet" type="text/css">
<!-- Global for the table -->

<!-- Core JS files -->
<script type="text/javascript" src="../assets/js/plugins/loaders/pace.min.js"></script>
<script type="text/javascript" src="../assets/js/core/libraries/jquery.min.js"></script>
<script type="text/javascript" src="../assets/js/core/libraries/bootstrap.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/loaders/blockui.min.js"></script>
<!-- /core JS files -->

<script type="text/javascript" src="../assets/js/plugins/notifications/jgrowl.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/ui/moment/moment.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/daterangepicker.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/anytime.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/picker.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/picker.date.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/picker.time.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/legacy.js"></script>

<script type="text/javascript" src="../assets/js/core/app.js"></script>
<script type="text/javascript" src="../assets/js/pages/picker_date.js"></script>

<script type="text/javascript" src="../assets/js/plugins/ui/ripple.min.js"></script>

<!-- Theme JS files -->
<script type="text/javascript" src="../assets/js/core/libraries/jquery_ui/interactions.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/forms/selects/select2.min.js"></script>

<script type="text/javascript" src="../assets/js/core/app.js"></script>
<script type="text/javascript" src="../assets/js/pages/form_select2.js"></script>

<script type="text/javascript" src="../assets/js/plugins/ui/ripple.min.js"></script>

</head>

<body id="background" class="layout-boxed navbar-bottom backpic">

		<!-- Main navbar AND Main menu-->
        <?php

                require_once '../Menu/menu_admin.php';

        ?>
        <!-- /page header -->


	<!-- Page container -->
	<div class="page-container">
		<!-- Page content -->
		<div class="page-content" id="Div1">
			<!-- Main content -->
			<div class="content-wrapper">
				<!-- Traffic sources -->
				<div class="panel panel-flat">
					<div class="panel-heading">
						<h6 class="panel-title">Agents Management</h6>
                    </div>
                    <?php
                                if(isset($_GET['err']) )
                                {	
                                    if($_GET['err'] == 1 )
                                    {
                                    echo "<a href='agents.php'><div class='alert alert-success alert-dismissible' role='alert'>
                                        <strong>Success!</strong> New Agent was added successfully Pending Activation.
                                        </div></a>";
                                    }		

                                    if($_GET['err'] == 3 )
                                    {
                                        echo "<a href='agents.php'><div class='alert alert-warning alert-dismissible' role='alert'>
                                        <strong>Warning!</strong> Sorry the TerminalID / Username entered has already been Created.
                                        </div></a>";
                                    }
                                    
                                    
                                    if($_GET['err'] == 5 )
                                    {
                                        echo "<a href='agents.php'><div class='alert alert-success alert-dismissible' role='alert'>
                                        <strong>Success!</strong> Agent details where updated successfully.
                                        </div></a>";
                                    }

                                    if($_GET['err'] == 4 )
                                    {
                                        echo "<a href='agents.php'><div class='alert alert-success alert-dismissible' role='alert'>
                                        <strong>Success!</strong> Agent Profile was deleted successfully.
                                        </div></a>";
                                    }

                                    if($_GET['err'] == 6 )
                                    {
                                        echo "<a href='agents.php'><div class='alert alert-success alert-dismissible' role='alert'>
                                        <strong>Success!</strong> Agent Password was reset successfully.
                                        </div></a>";
                                    }

                                    if($_GET['err'] == 7 )
                                    {
                                        echo "<a href='agents.php'><div class='alert alert-danger alert-dismissible' role='alert'>
                                        <strong>Sorry!</strong> Sorry No was ID was fund in the system.
                                        </div></a>";
                                    }
                                            
                                }
                    ?>	
					<div class="container-fluid" style="margin-top:5px;">
						<div class="row">
						<div class="col-lg-2">
								<ul class="list-inline text-center">
									<li>
										<a href="#" class="btn border-teal text-teal btn-flat btn-rounded btn-icon btn-xs valign-text-bottom"><i class="icon-people"></i></a>
									</li>
									<li class="text-left">
											<div class="text-semibold">Total Agents</div>
											<div class="text-muted top-1"><span class="status-mark border-success position-left"></span><?php echo $row2['yonse'];?></div>
									</li>
								</ul>

								<div class="col-lg-10 col-lg-offset-1">
									<div class="content-group" id="new-visitors"></div>
								</div>
							</div>
							<div class="col-lg-2">
								<ul class="list-inline text-center">
									<li>
										<a href="#" class="btn border-teal text-teal btn-flat btn-rounded btn-icon btn-xs valign-text-bottom"><i class="icon-checkmark3"></i></a>
									</li>
									<li class="text-left">
											<div class="text-semibold">Active Agents </div>
											<div class="text-muted top-1"><span class="status-mark border-success position-left"></span><?php echo $row1['active'];?></div>
									</li>
								</ul>
								<div class="col-lg-10 col-lg-offset-1">
									<div class="content-group" id="new-visitors"></div>
								</div>
							</div>
							<div class="col-lg-2">
								<ul class="list-inline text-center">
									<li>
										<a href="#" class="btn border-danger-400 text-danger-400 btn-flat btn-rounded btn-icon btn-xs valign-text-bottom"><i class="icon-blocked"></i></a>
									</li>
									<li class="text-left">
											<div class="text-semibold">Declined Agents</div>
											<div class="text-muted top-1"><span class="status-mark border-success position-left"></span> <?php echo $row3['bamapulobuleme'];?></div>
									</li>
								</ul>
								<div class="col-lg-10 col-lg-offset-1">
									<div class="content-group" id="new-sessions"></div>
								</div>
							</div>
                            <div class="col-lg-2">
								<ul class="list-inline text-center">
									<li>
										<a href="#" class="btn border-danger-400 text-danger-400 btn-flat btn-rounded btn-icon btn-xs valign-text-bottom"><i class="icon-blocked"></i></a>
									</li>
									<li class="text-left">
											<div class="text-semibold">Deactivated Agents</div>
											<div class="text-muted top-1"><span class="status-mark border-success position-left"></span><?php echo $row4['bantota'];?></div>
									</li>
								</ul>
								<div class="col-lg-10 col-lg-offset-1">
									<div class="content-group" id="new-sessions"></div>
								</div>
							</div>
                            <div class="col-lg-2">
								<ul class="list-inline text-center">
									<li>
										<a href="#" class="btn border-warning-400 text-warning-400 btn-flat btn-rounded btn-icon btn-xs valign-text-bottom"><i class="icon-blocked"></i></a>
									</li>
									<li class="text-left">
											<div class="text-semibold">Pending Agents</div>
											<div class="text-muted top-1"><span class="status-mark border-success position-left"></span><?php echo $row5['bamoyo'];?></div>
									</li>
								</ul>
								<div class="col-lg-10 col-lg-offset-1">
									<div class="content-group" id="new-sessions"></div>
								</div>
                            </div>
                            
							<!--<div class="col-lg-2">
								<ul class="list-inline text-center">
									<li>
                                        <a href="#" class="btn border-indigo-400 text-indigo-400 btn-flat btn-rounded btn-icon btn-xs valign-text-bottom" data-toggle="modal" data-target="#myModal"><i class="icon-plus3"></i></a>
									</li>
									<li class="text-left">
										<div class="text-semibold">Add New Agent</div>
										<div class="text-muted top-1"><span class="status-mar border-success position-left"></span></div>
									</li>
								</ul>
								<div class="col-lg-10 col-lg-offset-1">
									<div class="content-group" id="total-online"></div>
                                </div>
                                
							</div>-->
						</div>
					</div>
                    <hr>
                                        <div id="reportsTable" style="width:98%;margin:auto;">
                                        <table id="example" class="display" style="width:100%;font-size:10px;">
                                            <thead>
                                            <tr>
                                                <th>TerminalID</th>
                                                <th>Username</th>
                                                <th>FirstName</th>
                                                <th>LastName</th>
                                                <th>NRC</th>
                                                <th>Email</th>
                                                <th>Mobile</th>
                                                <th>Status</th>
                                                <th>B/C</th>
                                                <th style="width:140px;text-align:center">Action</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php                              
									$sql = "SELECT* FROM merchants";
										$result = $conn->query($sql);
									if ($result->num_rows > 0) {
										while($row = $result->fetch_assoc()) {
                                            $id = $row['agentID'];
                                   echo"<tr class='odd gradeX'>
											<td>{$row["terminalID"]}</td>
											<td>{$row["userName"]}</td>
											<td>{$row["firstName"]}</td>
											<td>{$row["lastName"]}</td>
											<td>{$row["agentNRC"]}</td>
											<td>{$row["email"]}</td>
											<td>{$row["mobile"]}</td>
											<td>{$row["status"]}</td>
											<td style='text-align:right;'>K{$row["AvailableBalance"]}</td>
											<td style='text-align:center;width:30px;'>";
											
                                            if($row["status"] == 'Active'){
                                                echo"<div class='form-group' style='margin-bottom:-3px;'>
                                                            <button type='button' class='btn btn-default btn-icon dropdown-toggle batoz' data-toggle='dropdown'>Actions</button>
                                                            <ul class='dropdown-menu dropdown-menu-right'>
                                                                <li><a href=\"loadValue.php?id=" . $row['agentID'] ."\" > Load Value </a></li>
                                                                <li><a href=\"resetPasswordAgent.php?id=" . $row['agentID'] ."\" >Password Rest</a></li>
                                                                <li><a href=\"agent_update.php?id=" . $row['agentID'] ."\" >Update Profile details</a></li>
                                                            </ul>
                                                  
                                                </div>";
                                            }


                                            if($row["status"] == 'Disabled'){
                                                echo"<div class='form-group' style='margin-bottom:-3px;'>
                                                            <button type='button' class='btn btn-default btn-icon dropdown-toggle batoz' data-toggle='dropdown'>Actions</button>
                                                            <ul class='dropdown-menu dropdown-menu-right'>
                                                                <li><a href='#' > Load Value </a></li>
                                                                <li><a href='#' >Password Rest</a></li>
                                                                <li><a href=\"agent_update.php?id=" . $row['agentID'] ."\" >Update Profile details</a></li>
                                                            </ul>
                                                  
                                                </div>";
                                            }

											if($row["status"] == 'Pending'){
												echo"&nbsp;&nbsp;&nbsp;
                                                <input type='button' name='edit' value='Pending' id='$id' class='edit_data  btn btn-warning btn-xs batoz'/>";
											}
											
										echo"</td>
                                    </tr>";
                                        }}
                            ?>
                         </tbody>
                     </table>
                   </div>
				</div>
                <!-- /traffic sources -->
                <!-- Modal content number1 starts here-->
                <div class="modal fade" id="myModal" role="dialog">
                        <div class="modal-dialog">
                        <!-- Modal content-->
                        <div class="modal-content">
                            <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title">Agents Details</h4>
                            </div>
                            <div class="modal-body">
                            <form class="form-horizontal" action="createAgent.php" method="POST">
                                <fieldset class="content-group">
                                    <legend class="text-bold" style="font-size:10px;color:red;"><i>All fields are required*</i></legend>

                                    <div class="form-group client1">
                                        <label class="control-label col-lg-4" style="text-align:right;">First Name</label>
                                        <div class="col-lg-6">
                                            <div class="input-group input-group-xlg">
                                                <span class="input-group-addon"></span>
                                                <input type="text" class="form-control" name="fname" required autocomplete="off">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group client1">
                                        <label class="control-label col-lg-4" style="text-align:right;">Last Name</label>
                                        <div class="col-lg-6">
                                            <div class="input-group input-group-lg">
                                                <span class="input-group-addon"></span>
                                                <input type="text" class="form-control" name="lname" required autocomplete="off">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group client1">
                                        <label class="control-label col-lg-4" style="text-align:right;">NRC</label>
                                        <div class="col-lg-6">
                                            <div class="input-group">
                                                <span class="input-group-addon"></span>
                                                <input type="text" class="form-control" maxlength="9" name="nrc" required autocomplete="off">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group client1">
                                        <label class="control-label col-lg-4" style="text-align:right;">Username</label>
                                        <div class="col-lg-6">
                                            <div class="input-group input-group-sm">
                                                <span class="input-group-addon"></span>
                                                <input type="text" class="form-control" name="username"  required autocomplete="off">
                                            </div>
                                        </div>
                                    </div>

                                     <div class="form-group client1">
                                        <label class="control-label col-lg-4" style="text-align:right;">TerminalID</label>
                                        <div class="col-lg-6">
                                            <div class="input-group input-group-sm">
                                                <span class="input-group-addon"></span>
                                                <input type="text" class="form-control" name="terminalid" required autocomplete="off">
                                            </div>
                                        </div>
                                    </div>

                                     <div class="form-group client1">
                                        <label class="control-label col-lg-4" style="text-align:right;">Agents Mobile Number(260)</label>
                                        <div class="col-lg-6">
                                            <div class="input-group input-group-sm">
                                                <span class="input-group-addon"></span>
                                                <input type="text" class="form-control" maxlength="12" name="mobile" required autocomplete="off">
                                            </div>
                                        </div>
                                    </div>

                                     <div class="form-group client1">
                                        <label class="control-label col-lg-4" style="text-align:right;">Email</label>
                                        <div class="col-lg-6">
                                            <div class="input-group input-group-sm">
                                                <span class="input-group-addon"></span>
                                                <input type="text" class="form-control" name="email" required autocomplete="off">
                                                  <?php
                                                        function random_password( $length = 6 ) {
                                                            $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$";
                                                            $password = substr( str_shuffle( $chars ), 0, $length );
                                                            return $password;
                                                        }
                                                    ?>
                                                    <input type="hidden" class="form-control" name='pass' value="<?php echo $password = random_password(6);?>">
                                                    <input type="hidden" class="form-control" name='date' value="<?php echo date("Y-m-d");?>">
                                                    <div class="form-group">
                                                        <input class="form-control" name="status" 		type="hidden"  value ="Pending"   required>
                                                    </div>
                                            </div>
                                        </div>
                                    </div>
                                </fieldset>
                                <div class="btn-group btn-group-xs" style="margin-left:50px;">
                                    <button type="submit" name="submit" class="btn btn-success" style="height:24px;line-height:4px;">Add New Agent</button>
                                </div>
                            </form>
                            </div>
                        </div>
                        </div>
                    </div>

<!-- Modal content number2  for editing the clients details after decline starts here-->
                   
     <!--Edit Item Modal -->
        <div id="add_data_modal" class="modal fade" >
            <form action="edit1.php" method="POST" class="form-horizontal" role="form">
                <div class="modal-dialog modal-lg">
                    <!-- Modal content-->
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title">Declined Profile Details</h4>
                        </div>
                        <div class="modal-body">
                            <input type="hidden" name="agent_id" id="agent_id">
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="item_name">Fist Name:</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" id="fname" name="fname"  required >
                                </div>
                                <label class="control-label col-sm-2" for="item_code">Last Name:</label>
                                <div class="col-sm-4">
                                    <input type="text"  class="form-control" id="lname" name="lname"  required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="item_name">NRC:</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" id="nrc" maxlength="9" name="nrc"  required >
                                </div>
                                <label class="control-label col-sm-2" for="item_code">Username:</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" id="username" name="username"  required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="item_name">TerminalID:</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" id="terminalid" name="terminalid" required >
                                </div>
                                <label class="control-label col-sm-2" for="item_code">Mobile Number:</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" id="mobile" maxlength="12" name="mobile" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="item_code">Email:</label>
                                <div class="col-sm-4">
                                    <input type="text"  class="form-control" id="email" name="email"  required>
                                </div>

                                <label class="control-label col-sm-2" for="item_code">Profile Status:</label>
                                <div class="col-sm-4">
                                    <input type="text"  class="form-control" id="status" name="status"  required>
                                </div>
                            </div>
                            <div class="form-group">
                                
                            <label class="control-label col-sm-2" style="color:red;" for="item_category">Creator Remarks:</label>
                                <div class="col-sm-4">
                                    <input type="text" style="color:red;" class="form-control" id="profileReason"  name="profileReason">
                                    <input type="hidden" class="form-control" id="agentID"  name="agentID">
                                    <input type="hidden" class="form-control"    name="status"  value="Declined">
                                    <input type="hidden" class="form-control"    name="date"    value="<?php echo date('Y-m-d');?>">
                                    <input type="hidden" class="form-control"    name="editor"  value="<?php echo $_SESSION['sess_firstname']." ".$_SESSION['sess_lastname'];?>">
                                </div>

                                <label class="control-label col-sm-2" style="text-align:right;">Select Status</label>
                                        <div class="col-sm-4">
                                        <select class="select" name="status" required>
                                                <option value=""></option>
                                                <option value="Active">Active</option>
                                                <option value="Declined">Decline</option>
                                        </select>
                                        </div>


                                <label class="control-label col-sm-2" for="item_description">Enter Your Remarks:</label>
                                <div class="col-sm-4">
                                    <textarea class="form-control"  name="comment" placeholder="Enter your remarks" required style="width: 100%;"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary batoz" name="insert" id ="insert"> Edit</button>
                            <button type="button" class="btn btn-warning batoz" data-dismiss="modal"> Cancel</button>
                        </div>
                    </div>
                </div>

            <script>
                    $(document).ready(function(){
                    
                    $(document).on('click', '.edit_data', function(){
                        var agent_id = $(this).attr("id");
                        $.ajax({
                            url:"fetch.php",
                            method:"POST",
                            data:{agent_id:agent_id},
                            dataType:"json",
                            success:function(data){
                                $('#fname').val(data.firstName);
                                $('#lname').val(data.lastName);
                                $('#nrc').val(data.agentNRC);
                                $('#terminalid').val(data.terminalID);
                                $('#username').val(data.userName);
                                $('#mobile').val(data.mobile);
                                $('#email').val(data.email);
                                $('#status').val(data.status);
                                $('#agentID').val(data.agentID);
                                $('#profileReason').val(data.profileReason);
                                $('#insert').val("update");
                                $('#add_data_modal').modal('show');
                                
                            }
                        
                        });
                    
                    });
                    
                });
            </script>
        </div>
        </form>
        </div>


            </div>
            <!-- /content area -->
        </div>
            <!-- /page content -->
    </div>
	<!-- /page container -->
    <script>	
		$(document).ready(function() {
			$('#example').DataTable( {
				dom: 'Bfrtip',
				buttons: [
					{
						extend: 'copyHtml5',
						title: 'Uniturtule Transactions'
					},
					{
						extend: 'excelHtml5',
						title: 'Uniturtule Transactions'
					},
					{
						extend: 'csvHtml5',
						title: 'Uniturtule Transactions'
					},
					{
						extend: 'pdfHtml5',
						title: 'Uniturtule Transactions',
						orientation: 'landscape',
                		pageSize: 'LEGAL'
					},
					{
						extend: 'print',
						title: 'Uniturtule Transactions',
						orientation: 'landscape',
                		pageSize: 'LEGAL'
					}
				]
			} );
		} );
</script>
    
        <!-- /core JS for tables -->
        <script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.flash.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.print.min.js"></script>
        <script>
            $(document).ready(function () {
                $(document).on('click', '.get_client_id', function(){
                    var id = $(this).attr("id");
                    $('#id').val(id);
                    $('#myModal2').modal('show');
                })
             })
        </script>
        <!-- /core JS for tables -->

<!-- footer-->
<?php

require_once '../footer/footer.php';

?>
<!-- /Footer -->
</body>
</html>
