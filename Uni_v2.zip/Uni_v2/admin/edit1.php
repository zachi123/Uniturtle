<?php
    require_once '../config/session.php';
    require_once '../config/db_con.php';
?>
 
 <?php 
	  
	   if(isset($_POST["insert"]))
		  $id = $_POST['agentID'];
      { // <--- declare id here
	      
		$update = "UPDATE `merchants` SET 
		          `terminalID`		='$_POST[terminalid]',
		          `firstName`		='$_POST[fname]',
		          `lastName`		='$_POST[lname]',
		          `agentNRC`		='$_POST[nrc]',
		          `userName`		='$_POST[username]',
		          `email`			='$_POST[email]',
		          `status`			='$_POST[status]',
		          `updated_at`		='$_POST[date]',
		          `EditedBy`		='$_POST[editor]',
		          `mobile`			='$_POST[mobile]',
				  `profileReason`	='$_POST[comment]',
				  `patch`			='O'
				   WHERE `agentID`=$id";
				 
		$conn->query($update);
	
			echo "<script>window.open('agents.php?err=5','_self');</script>";

		  
	  }
	  
	  
	  
 ?>