<?php
    require_once '../config/session.php';
    require_once '../config/db_con.php';					
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Uniturtle</title>

<!-- Global stylesheets -->
<link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
<link href="../assets/css/icons/icomoon/styles.css" rel="stylesheet" type="text/css">
<link href="../assets/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="../assets/css/core.css" rel="stylesheet" type="text/css">
<link href="../assets/css/components.css" rel="stylesheet" type="text/css">
<link href="../assets/css/colors.css" rel="stylesheet" type="text/css">
<!-- /global stylesheets -->


<!-- Global for the table -->
<link href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css">
<link href="https://cdn.datatables.net/buttons/1.5.2/css/buttons.dataTables.min.css" rel="stylesheet" type="text/css">
<!-- Global for the table -->

<!-- Core JS files -->
<script type="text/javascript" src="../assets/js/plugins/loaders/pace.min.js"></script>
<script type="text/javascript" src="../assets/js/core/libraries/jquery.min.js"></script>
<script type="text/javascript" src="../assets/js/core/libraries/bootstrap.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/loaders/blockui.min.js"></script>
<!-- /core JS files -->

<script type="text/javascript" src="../assets/js/plugins/notifications/jgrowl.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/ui/moment/moment.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/daterangepicker.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/anytime.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/picker.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/picker.date.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/picker.time.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/legacy.js"></script>

<script type="text/javascript" src="../assets/js/core/app.js"></script>
<script type="text/javascript" src="../assets/js/pages/picker_date.js"></script>

<script type="text/javascript" src="../assets/js/plugins/ui/ripple.min.js"></script>

<!-- Theme JS files -->
<script type="text/javascript" src="../assets/js/core/libraries/jquery_ui/interactions.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/forms/selects/select2.min.js"></script>

<script type="text/javascript" src="../assets/js/core/app.js"></script>
<script type="text/javascript" src="../assets/js/pages/form_select2.js"></script>

<script type="text/javascript" src="../assets/js/plugins/ui/ripple.min.js"></script>

</head>

<body id="background" class="layout-boxed navbar-bottom backpic">

	<!-- Main navbar AND Main menu-->
    <?php

        require_once '../Menu/menu_admin.php';

    ?>
    <!-- /page header -->


	<!-- Page container -->
	<div class="page-container">
		<!-- Page content -->
		<div class="page-content">
			<!-- Main content -->
			<div class="content-wrapper">
				<!-- Traffic sources -->
				<div class="panel panel-flat">

        <div id="a" class="m" >
            <form action="update_agent.php" method="POST" class="form-horizontal" role="form">
                <div class="modal-dialog modal-lg">

                    
                     <?php

                            if(isset($_GET['id'])){
                                
                                $id = $_GET['id'];
                                $sql = "SELECT* FROM `merchants` WHERE `agentID` = '$id'";
                                $result = $conn->query($sql);
                                $row = $result->fetch_assoc();


                            }
                    
                    ?>
                    <!-- Modal content-->
                    <div class="modal-content" style="width: 1160px;margin-left: -129px;">
                        <div class="modal-header">
                            <h4 class="modal-title">Update Agents Profile</h4>
                        </div>
                        <div class="modal-body">
                            <input type="hidden" name="agentID" value="<?php echo $row['agentID'];?>">
                            <div class="form-group">
                                <label class="control-label col-sm-2 sudosisi" for="item_name"  style='text-align:right;'>First Name:</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" name="fname" value ="<?php echo $row['firstName'];?>" required >
                                </div>
                                <label class="control-label col-sm-2" for="item_code"  style='text-align:right;'>Last Name:</label>
                                <div class="col-sm-4">
                                    <input type="text"  class="form-control" name="lname" value ="<?php echo $row['lastName'];?>" >
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="item_name"  style='text-align:right;'>User Name:</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" name="username" value ="<?php echo $row['userName'];?>"  >
                                </div>
                                <label class="control-label col-sm-2" for="item_code"  style='text-align:right;'>TerminalID:</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" name="terminalid" value ="<?php echo $row['terminalID'];?> "  >
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="item_name"  style='text-align:right;'>Agent NRC:</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" name="nrc" value ="<?php echo $row['agentNRC'];?>" >
                                </div>

                                <label class="control-label col-sm-2" for="item_name"  style='text-align:right;'>Email Address:</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" name="email" value ="<?php echo $row['email'];?>"  >
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="item_code"  style='text-align:right;'>Mobile Number:</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" name="mobile" value ="<?php echo $row['mobile'];?>" required  >
                                </div>
                                
                                <label class="control-label col-sm-2" for="item_code"  style='text-align:right;'>Status:</label>
                                <div class="col-sm-4">
                                <select class="select" name="status" required>
                                        <option value=""><?php echo $row['status'];?></option>
                                        <option value="Active">Active</option>
                                        <option value="Disabled">Disable</option>
                                </select>
                                </div>

                            </div>
                            <div class="form-group">
                                <div class="col-sm-8">
                                <div class="modal-footer">
                                 
                            </div>
                        </div>
                    </div>
                        </div>
                        <div class="modal-footer">
                            <button type='submit' class='btn btn-primary btn-xs batoz' name='insert'>Update Profile </button>
                            <a href="agents.php"  class="btn btn-warning batoz" data-dismiss="modal"> Cancel</a>
                            
                        </div>
                    </div>
                </div>
                   </div>
				</div>
					</div>

                    <!-- /content area -->
                    </div>
                    <!-- /page content -->
                 </div>
             </div>
        </div>
    </div>
    <!-- /page container -->
	<!-- footer-->
    <?php

        require_once '../footer/footer.php';

        ?>
<!-- /Footer -->
</body>
</html>
