<?php
    require_once '../config/session.php';
    require_once '../config/db_con.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Uniturtle</title>

<!-- Global stylesheets -->
<link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
<link href="../assets/css/icons/icomoon/styles.css" rel="stylesheet" type="text/css">
<link href="../assets/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="../assets/css/core.css" rel="stylesheet" type="text/css">
<link href="../assets/css/components.css" rel="stylesheet" type="text/css">
<link href="../assets/css/colors.css" rel="stylesheet" type="text/css">
<!-- /global stylesheets -->


<!-- Global for the table -->
<link href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css">
<link href="https://cdn.datatables.net/buttons/1.5.2/css/buttons.dataTables.min.css" rel="stylesheet" type="text/css">
<!-- Global for the table -->

<!-- Core JS files -->
<script type="text/javascript" src="../assets/js/plugins/loaders/pace.min.js"></script>
<script type="text/javascript" src="../assets/js/core/libraries/jquery.min.js"></script>
<script type="text/javascript" src="../assets/js/core/libraries/bootstrap.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/loaders/blockui.min.js"></script>
<!-- /core JS files -->

<script type="text/javascript" src="../assets/js/plugins/notifications/jgrowl.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/ui/moment/moment.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/daterangepicker.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/anytime.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/picker.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/picker.date.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/picker.time.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/legacy.js"></script>

<script type="text/javascript" src="../assets/js/core/app.js"></script>
<script type="text/javascript" src="../assets/js/pages/picker_date.js"></script>

<script type="text/javascript" src="../assets/js/plugins/ui/ripple.min.js"></script>

<!-- Theme JS files -->
<script type="text/javascript" src="../assets/js/core/libraries/jquery_ui/interactions.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/forms/selects/select2.min.js"></script>

<script type="text/javascript" src="../assets/js/core/app.js"></script>
<script type="text/javascript" src="../assets/js/pages/form_select2.js"></script>

<script type="text/javascript" src="../assets/js/plugins/ui/ripple.min.js"></script>

</head>

<body id="background" class="layout-boxed navbar-bottom backpic">

	<!-- Main navbar AND Main menu-->
    <?php

            require_once '../Menu/menu_admin.php';

    ?>
    <!-- /page header -->


	<!-- Page container -->
	<div class="page-container">
		<!-- Page content -->
		<div class="page-content" id="Div1">
			<!-- Main content -->
			<div class="content-wrapper">
				<!-- Traffic sources -->
				<div class="panel panel-flat">
					<div class="panel-heading">
						<h6 class="panel-title">
						<fieldset class="content-group" style="width:50%;float:right">
							<form action="reports.php" method="POST">
									<div class="form-group client1">
                                        <label class="control-label col-lg-2" style="text-align:right;">From</label>
                                        <div class="col-lg-2">
                                            <div class="input-group input-group-lg">
                                                <span class="input-group-addon"></span>
                                                <input type="date" class="form-control" name="start" required autocomplete="off">
                                            </div>
                                        </div>
									</div>
									<div class="form-group client1" style="margin-left:45%;">
                                        <label class="control-label col-lg-2" style="text-align:right;">To</label>
                                        <div class="col-lg-2">
                                            <div class="input-group input-group-lg">
                                                <span class="input-group-addon"></span>
                                                <input type="date" class="form-control" name="end" required autocomplete="off">
                                            </div>
                                        </div>
									</div>
									<div class="btn-group btn-group-xs" style="margin-left:128px;">
                                       <button type="submit" name="pull" class="btn btn-success" style="height:24px;line-height:4px;">Fetch</button>
                                   </div>
							</form>
						</fieldset>
						    <?php 
                                    if(isset($_POST["start"])){
                                        echo 'Payments Between '.  $_POST["start"]. ' And '. $_POST["end"];
                                    }else{
                                        echo 'All Transactions on the System';
                                    }
                            ?>
						
						</h6>
						<div class="heading-elements">
						</div>
					</div>
					<div class="container-fluid" style="margin-top:2px;width:98%;">
                    </div>
                   <hr>
                   <div id="reportsTable" style="width:98%;margin:auto;">
                    <table id="example" class="display" style="width:100%;font-size:10px;">
                        <thead>
                            <tr>
							<th>Transaction Date</th>
                            <th>Transaction Ref</th>
                            <th>Transaction Type</th>
                            <th>NRC</th>
                            <th>Policy Owner</th>
                            <th>Amount</th>
                            <th>Agent Name</th>
                            <th>TerminalID</th>
                            </tr>
                        </thead>
                        <?php                     

                    if(isset($_POST["pull"])){
									 $startDate  = $_POST["start"] ." "."00:00:00";
								     $endDate	 = $_POST["end"] ." "."00:00:00";
								
									// Create connection
								$conn = new mysqli($servername, $username, $password, $dbname);		      	
		
// Check connection
									if ($conn->connect_error) {
										die("Connection failed: " . $conn->connect_error);
									} 
//Query selecting all data from the database_table issues
									$sql = "SELECT* FROM `transactions` WHERE `transactionDate`>='$startDate 00:00:00am' AND `transactionDate`<='$endDate 00:00:00am'";
										$result = $conn->query($sql);
									if ($result->num_rows > 0) {
                                    while($row = $result->fetch_assoc()) {										
                                    echo"<tr class='odd gradeX'>
                                        <td>{$row["transactionDate"]}</td>
                                        <td>{$row["transactionRef"]}</td>
                                        <td>{$row["transactionType"]}</td>
                                        <td>{$row["nrc"]}</td>
                                        <td>{$row["policyOwner"]}</td>
                                        <td>{$row["amount"]}</td>
                                        <td>{$row["agentName"]}</td>
                                        <td>{$row["terminalID"]}</td>
                                    </tr>";
						          }}
									
						}elseif(!isset($_POST["pull"])){
// Create connection
								$conn = new mysqli($servername, $username, $password, $dbname);		      	
		
// Check connection
									if ($conn->connect_error) {
										die("Connection failed: " . $conn->connect_error);
									} 
//Query selecting all data from the database_table issues						
										$sql = "SELECT* FROM transactions";
										$result = $conn->query($sql);
									if ($result->num_rows > 0) {
                                    while($row = $result->fetch_assoc()) {										
                                    echo"<tr class='odd gradeX'>
                                        <td>{$row["transactionDate"]}</td>
                                        <td>{$row["transactionRef"]}</td>
                                        <td>{$row["transactionType"]}</td>
                                        <td>{$row["nrc"]}</td>
                                        <td>{$row["policyOwner"]}</td>
                                        <td>{$row["amount"]}</td>
                                        <td>{$row["agentName"]}</td>
                                        <td>{$row["terminalID"]}</td>
                                    </tr>";
						          }}
							
						} 

?>									
                                </tbody>
                            </table>
				  </div>
				</div>
				<!-- /traffic sources -->
			</div>
			<!-- /content area -->
		</div>
    <!-- /page content -->
	</div>
	<!-- /page container -->
    <!-- Footer -->
    <script>	
		$(document).ready(function() {
			$('#example').DataTable( {
				dom: 'Bfrtip',
				buttons: [
					{
						extend: 'copyHtml5',
						title: 'Uniturtule Transactions'
					},
					{
						extend: 'excelHtml5',
						title: 'Uniturtule Transactions'
					},
					{
						extend: 'csvHtml5',
						title: 'Uniturtule Transactions'
					},
					{
						extend: 'pdfHtml5',
						title: 'Uniturtule Transactions',
						orientation: 'landscape',
                		pageSize: 'LEGAL'
					},
					{
						extend: 'print',
						title: 'Uniturtule Transactions',
						orientation: 'landscape',
                		pageSize: 'LEGAL'
					}
				]
			} );
		} );
</script>

	<!-- /core JS for tables -->
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.flash.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.print.min.js"></script>
	<!-- /core JS for tables -->
	<!-- footer-->
	<?php

require_once '../footer/footer.php';

?>
<!-- /Footer -->

</body>
</html>
