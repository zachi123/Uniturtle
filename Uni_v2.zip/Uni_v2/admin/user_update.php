<?php
    require_once '../config/session.php';
    require_once '../config/db_con.php';
?>
 
 <?php 
	  
	   if(isset($_POST["insert"]))
		  $id = $_POST['userID'];
      { // <--- declare id here
	      
		$update = "UPDATE `users` SET 
		          `firstname`		='$_POST[fname]',
		          `lastname`		='$_POST[lname]',
		          `gender`		    ='$_POST[gender]',
		          `username`		='$_POST[username]',
		          `email`			='$_POST[gender1]',
		          `status`			='$_POST[status]',
		          `role`			='$_POST[role]',
		          `mobile`			='$_POST[gender2]'
				   WHERE `userID`   =$id";	 
		$conn->query($update);
	
			echo "<script>window.open('users.php?err=5','_self');</script>";

		  
	  }
	  
	  
	  
 ?>