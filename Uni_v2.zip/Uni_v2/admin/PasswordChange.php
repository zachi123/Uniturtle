<?php
	require_once '../config/session.php';
    require_once '../config/db_con.php';	
    
       // Did the user submit the form?
       if(isset($_POST['submit'])){
        // Process the form
         
        $current_password    = $_POST['currentPassword'];
        $new_password        = $_POST['newPassword'];
        $conf_password       = $_POST['confirmPassword'];
         
        $check_current_password  = trim($current_password);
        $check_new_password      = trim($new_password);
        $Check_conf_password     = trim($conf_password);


        $hashed_check_current_password = md5($check_current_password); 
        $hashed_check_new_password     = md5($check_new_password);
        $hashed_Check_conf_password    = md5($Check_conf_password);
        $id  = $_SESSION['sess_userID'];

        
         
        if($hashed_check_current_password == $_SESSION['sess_password']){
      
            if($hashed_check_new_password == $hashed_Check_conf_password){

                $update = "UPDATE `users` SET 
		          `password`		='$hashed_check_new_password'
				   WHERE `userID`= $id";
				 
		          $conn->query($update);
	
			      echo "<script>window.open('changePassword.php?err=3','_self');</script>";

            }else{

                echo "<script>window.open('changePassword.php?err=2','_self');</script>";
            }

        }else{

                echo "<script>window.open('changePassword.php?err=1','_self');</script>";
        }
    }


?>