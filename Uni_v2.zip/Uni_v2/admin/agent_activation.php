<?php
    require_once '../config/session.php';
    require_once '../config/db_con.php';					
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Uniturtle</title>

<!-- Global stylesheets -->
<link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
<link href="../assets/css/icons/icomoon/styles.css" rel="stylesheet" type="text/css">
<link href="../assets/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="../assets/css/core.css" rel="stylesheet" type="text/css">
<link href="../assets/css/components.css" rel="stylesheet" type="text/css">
<link href="../assets/css/colors.css" rel="stylesheet" type="text/css">
<!-- /global stylesheets -->


<!-- Global for the table -->
<link href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css">
<link href="https://cdn.datatables.net/buttons/1.5.2/css/buttons.dataTables.min.css" rel="stylesheet" type="text/css">
<!-- Global for the table -->

<!-- Core JS files -->
<script type="text/javascript" src="../assets/js/plugins/loaders/pace.min.js"></script>
<script type="text/javascript" src="../assets/js/core/libraries/jquery.min.js"></script>
<script type="text/javascript" src="../assets/js/core/libraries/bootstrap.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/loaders/blockui.min.js"></script>
<!-- /core JS files -->

<script type="text/javascript" src="../assets/js/plugins/notifications/jgrowl.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/ui/moment/moment.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/daterangepicker.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/anytime.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/picker.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/picker.date.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/picker.time.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/legacy.js"></script>

<script type="text/javascript" src="../assets/js/core/app.js"></script>
<script type="text/javascript" src="../assets/js/pages/picker_date.js"></script>

<script type="text/javascript" src="../assets/js/plugins/ui/ripple.min.js"></script>

<!-- Theme JS files -->
<script type="text/javascript" src="../assets/js/core/libraries/jquery_ui/interactions.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/forms/selects/select2.min.js"></script>

<script type="text/javascript" src="../assets/js/core/app.js"></script>
<script type="text/javascript" src="../assets/js/pages/form_select2.js"></script>

<script type="text/javascript" src="../assets/js/plugins/ui/ripple.min.js"></script>

</head>

<body id="background" class="layout-boxed navbar-bottom backpic">

	<!-- Main navbar AND Main menu-->
    <?php

        require_once '../Menu/menu_admin.php';

    ?>
    <!-- /page header -->


	<!-- Page container -->
	<div class="page-container">
		<!-- Page content -->
		<div class="page-content">
			<!-- Main content -->
			<div class="content-wrapper">
				<!-- Traffic sources -->
				<div class="panel panel-flat">

                    <?php
                                if(isset($_GET['err']) )
                                {	
                                
                                if($_GET['err'] == 10 )
                                {
                                echo "<a href='clients.php'><div class='alert alert-success alert-dismissible' role='alert'>
                                    <strong>Success!</strong> Premium number was assinged to the client Successfully.
                                    </div></a>";
                                }

                                if($_GET['err'] == 11 )
                                {
                                echo "<a href='clients.php'><div class='alert alert-warning alert-dismissible' role='alert'>
                                    <strong>Warning!</strong> Premium number has already been assinged.
                                    </div></a>";
                                }

                                if($_GET['err'] == 12 )
                                {
                                echo "<a href='clients.php'><div class='alert alert-danger alert-dismissible' role='alert'>
                                    <strong>Declined!</strong> You just declined one client profile.
                                    </div></a>";
                                }
                                
                            }
                        ?>
                    
					<div class="container-fluid" style="margin-top:5px;">
						<div class="row">
        <?php

        if($_GET['id']){
            
            $id = $_GET['id'];
            $sql = "SELECT* FROM clients WHERE `clientID` = '$id'";
            $result = $conn->query($sql);
            $row = $result->fetch_assoc();

        }

        $coverCoder = $row["primiumType"];

        $sql1 = "SELECT* FROM `premiums` WHERE premCode = '$coverCoder'";
        $result = $conn->query($sql1);
        $row1 = $result->fetch_assoc();
         
        ?>
                                                  <!--Edit Item Modal -->
        <div id="ad" class="m" >
            <form action="decline.php" method="POST" class="form-horizontal" role="form">
                <div class="modal-dialog modal-lg">
                    <!-- Modal content-->
                    <div class="modal-content"  style="width: 1160px;margin-left: -129px;">
                        <div class="modal-header">
                            <h4 class="modal-title">Activate Clients Profile</h4>
                        </div>
                        <div class="modal-body">
                            <input type="hidden" name="client_id" id="client_id">
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="item_name">Clients Name:</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" placeholder="<?php echo $row['clientName'];?>"   >
                                </div>
                                <label class="control-label col-sm-2" for="item_code">Clents NRC:</label>
                                <div class="col-sm-4">
                                    <input type="text"  class="form-control" placeholder="<?php echo $row['NRC'];?>"  >
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="item_name">Date Of Birth:</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" placeholder="<?php echo $row['dateOfbirth'];?>"  >
                                </div>
                                <label class="control-label col-sm-2" for="item_code">Clients Mobile:</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" placeholder="<?php echo $row['mobile'];?> " >
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="item_name">Gender:</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" placeholder="<?php echo $row['gender'];?> " >
                                </div>
                                <label class="control-label col-sm-2" for="item_code">Premium:</label>
                                 <div class="col-sm-4">
                                    <input type="text" class="form-control" placeholder="<?php echo $row['primiumType'];?> " >
                                </div>
                            </div>
                            <div class="form-group">
                            
                            <label class="control-label col-sm-2" for="item_code">Status:</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" placeholder="<?php echo $row['status'];?> " >
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="item_code">Cover:</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" placeholder="K  <?php echo $row1['premiun_cover'];?> " >
                                </div>
                                
                            </div>
                            <?php
                              if($row['status'] == 'Pending'){
                               echo"<div class='form-group' style='color:red;'>
                                        <label class='control-label col-sm-2' for='item_code'>Comment:</label>
                                        <div class='col-sm-4' style='color:red;'>
                                            <input type='text'  style='color:red;' class='form-control' placeholder=". $row['profileReason'] ."";
                                    echo"</div></div>";
                             
                              }else{

                              }
                            ?>
                            <div class="form-group">
                                <div class="col-sm-8">
                                <div class="modal-footer">
                                <button type='button' class='btn btn-primary btn-xs batoz' name='answer' value='Show Div' onclick='showDiv2()'>Activate Profile </button>
                                <button type='button' class='btn btn-danger btn-xs batoz' name='answer' value='Show Div' onclick='showDiv1()'>Decline Profile</button>
                                
                                <div id='welcomeDiv1'  style='display:none;' class='answer_list' > 
                                    <hr/>	
                                    <form action='decline.php' method='POST'>
                                            <label class="control-label col-sm-4" for="item_description">Enter Your Remarks:</label>
                                                <div class="col-sm-6">
                                                    <textarea class="form-control"  name="resoan" placeholder="Enter your remarks" required style="width: 100%;"></textarea>
                                                    <input type='hidden' name='clientID' value="<?php echo $row['clientID'];?>">
                                                </div>
                                                <button type='submit' class='btn btn-danger btn-xs batoz' name='send' value='Show Div'>Decline</button>
                                    </form>
                                </div>
                                
                            
                                <div id='welcomeDiv2'  style='display:none; margin-top:20px;' class='answer_list' > 
                                  <hr/>
                                    <form action='activate.php' method='POST'>
                                        <label class="control-label col-sm-4" for="item_name">Enter Reference Number:</label>
                                        <div class="col-sm-4">
                                            <input type="text" class="form-control" name="premiumnmuber"  required >
                                        </div>
                                        <input type='hidden' name='clientID' value="<?php echo $row['clientID'];?>">
                                        <button type='submit' class='btn btn-info btn-xs batoz' name='send' value='Show Div'>Activate</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                        </div>
                        <div class="modal-footer">
                            <a href="clients.php"  class="btn btn-warning batoz" data-dismiss="modal"> Cancel</a>
                            
                        </div>
                    </div>
                </div>
                   </div>
				</div>
					</div>

                    <!-- /content area -->
                    </div>
                    <!-- /page content -->
                 </div>
             </div>
        </div>
    </div>
    <!-- /page container -->
    <script>
                    function showDiv1() {
                        document.getElementById('welcomeDiv1').style.display = "block";
                        }
                        </script> 

                        <script>
                            function showDiv2() {
                        document.getElementById('welcomeDiv2').style.display = "block";
                        }
            </script>
	<!-- footer-->
    <?php

        require_once '../footer/footer.php';

        ?>
<!-- /Footer -->
</body>
</html>
