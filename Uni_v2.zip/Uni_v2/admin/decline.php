<?php  include '../config/session.php';?>
<?php include '../config/db_con.php';?>
<?php 
   
	 
              if(isset($_POST['send'])){
				  
				  $id 		= $_POST['clientID'];
				  $reason 	= $_POST['resoan'];
				  
                       $update = "UPDATE `clients` SET `status`='Declined', `profileReason`='$reason', `patch`='D' WHERE `clientID`=$id";
						$conn->query($update);
						
                    //die();  
					    //header('location:users.php');
						echo "<script>window.open('clients.php?err=12','_self');</script>";	
                }
			
?>