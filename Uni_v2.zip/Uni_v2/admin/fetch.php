<?php
    require_once '../config/session.php';
    require_once '../config/db_con.php';

    if(isset($_POST["agent_id"])){

            $query = "SELECT* FROM merchants WHERE agentID ='".$_POST["agent_id"]."'";
            $result = mysqli_query($conn, $query);
            $row = mysqli_fetch_array($result);
            echo json_encode($row);

    }

?>