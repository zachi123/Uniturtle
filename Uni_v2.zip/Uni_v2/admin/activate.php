<?php  include '../config/session.php';?>
<?php include '../config/db_con.php';?>
<?php 
   
	 
              if(isset($_POST["clientID"])){
				  
				   $pNum   =$_POST["premiumnmuber"]; 
				   $id     =$_POST["clientID"]; 
				   $result = $conn->query("SELECT `policyNumber` FROM clients WHERE `policyNumber` = '$pNum'");
				   
                              if($result->num_rows == 0) {
								  
							         $update = "UPDATE `clients` SET 
									`status`='Active', 
									`policyNumber` = '$pNum' 
									WHERE `clientID`='$id'";
									$conn->query($update);
									
							$msg ="Activated Client profile with policy number : " . $pNum ;
                            // Update the Audit taril table for this action by the user who has logged in//
									$userID					= $_SESSION['sess_userID'];
								    $ActionDate    		 	= date("Y-m-d h:i:sa");
									$ActionDoneBy			= $_SESSION['sess_firstname']." ".$_SESSION['sess_lastname'];
									$Action					= $msg;
									
									$log = "INSERT INTO `audit` (actionID, userID, actionDate, actionDoneBy, action)
									VALUES ('','$userID','$ActionDate','$ActionDoneBy','$Action')";
								    $conn->query($log);
									
								//die();  
									//header('location:users.php');
									echo "<script>window.open('clients.php?err=10','_self');</script>";
								  
					}else{
						          echo "<script>window.open('clients.php?err=11','_self');</script>";
						
					}
                       	
                }
			
?>