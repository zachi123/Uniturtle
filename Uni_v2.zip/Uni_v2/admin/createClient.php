<?php  include '../config/session.php';?>
<?php include '../config/db_con.php';?>
 
 <?php            
						 if(isset($_POST["submit"])){
								  $Names				= ucfirst($_POST["names"]);
								  $NRC					= $_POST["nrc"];
								  $Mobile				= $_POST["mobile"];
								  $Month				= $_POST["month"];
								  $Year    		 		= $_POST["year"];
								  $PolicyType			= $_POST["policyType"];
								  $premiumType			= $_POST["premiumType"];
								  $dateOfBirth			= $_POST["dateOfBirth"];
								  $Gender				= $_POST["gender"];
								  $Policy				= $_POST["policy"];
								  $Cover				= $_POST["cover"];
								  $status				= $_POST["status"];
								  $totalContribution	= 0;
								  
		   
							  $result = $conn->query("SELECT `NRC` FROM clients WHERE `NRC` = '$NRC'");
                              if($result->num_rows == 0){
								  
									$sql = "INSERT INTO `clients` (clientID, clientName, mobile, NRC, policyType, gender, dateOfbirth, policy, cover, policyNumber, month, year, status, primiumType, totalContribution)
									VALUES ('','$Names','$Mobile','$NRC','$PolicyType','$Gender','$dateOfBirth','$Policy','$Cover','NOTSET','$Month','$Year','$status','$premiumType','$totalContribution')";
								    $conn->query($sql);
									
									//die();
									
									$msg ="Created new client on the system pending activation with details : " . $Names ." , ". $NRC ."," .$Mobile.",". $PolicyType.",".$premiumType;
								
									// Update the Audit taril table for this action by the user who has logged in//
									$userID					= $_SESSION['sess_userID'];
								    $ActionDate    		 	= date("Y-m-d h:i:sa");
									$ActionDoneBy			= $_SESSION['sess_firstname']." ".$_SESSION['sess_lastname'];
									$Action					= $msg;
									
									$log = "INSERT INTO `audit` (actionID, userID, actionDate, actionDoneBy, action)
									VALUES ('','$userID','$ActionDate','$ActionDoneBy','$Action')";
								    $conn->query($log);


									//echo "Check your email now....<BR/>";
											//this redirects to the all users page	   
										echo "<script>window.open('clients.php?err=3','_self');</script>";
									
									//header("location:clients.php?st=2");	
	 
								} else {

         							echo "<script>window.open('clients.php?err=2','_self');</script>";
								}	
								  
								 

}										
							
							
?>	 