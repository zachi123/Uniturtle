<?php
    require_once '../config/session.php';
    require_once '../config/db_con.php';



    	///QUERY PULL Clients DETAILS
	$sqlSum = "SELECT count(*) AS active FROM clients WHERE `status` ='Active'";
	$result = $conn->query($sqlSum);
    $row1 = $result->fetch_assoc();

    $sqlSum = "SELECT count(*) AS yonse FROM `clients`";
	$result = $conn->query($sqlSum);
    $row2 = $result->fetch_assoc();

    $sqlSum = "SELECT count(*) AS bamapulobuleme FROM `clients` WHERE `status` ='Declined'";
	$result = $conn->query($sqlSum);
    $row3 = $result->fetch_assoc();

    $sqlSum = "SELECT count(*) AS bantota FROM `clients` WHERE `status` ='Disabled'";
	$result = $conn->query($sqlSum);
    $row4 = $result->fetch_assoc();

    $sqlSum = "SELECT count(*) AS bamoyo FROM `clients` WHERE `status` ='Pending'";
	$result = $conn->query($sqlSum);
    $row5 = $result->fetch_assoc();
    						
					
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Uniturtle</title>

<!-- Global stylesheets -->
<link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
<link href="../assets/css/icons/icomoon/styles.css" rel="stylesheet" type="text/css">
<link href="../assets/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="../assets/css/core.css" rel="stylesheet" type="text/css">
<link href="../assets/css/components.css" rel="stylesheet" type="text/css">
<link href="../assets/css/colors.css" rel="stylesheet" type="text/css">
<!-- /global stylesheets -->


<!-- Global for the table -->
<link href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css">
<link href="https://cdn.datatables.net/buttons/1.5.2/css/buttons.dataTables.min.css" rel="stylesheet" type="text/css">
<!-- Global for the table -->

<!-- Core JS files -->
<script type="text/javascript" src="../assets/js/plugins/loaders/pace.min.js"></script>
<script type="text/javascript" src="../assets/js/core/libraries/jquery.min.js"></script>
<script type="text/javascript" src="../assets/js/core/libraries/bootstrap.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/loaders/blockui.min.js"></script>
<!-- /core JS files -->

<script type="text/javascript" src="../assets/js/plugins/notifications/jgrowl.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/ui/moment/moment.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/daterangepicker.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/anytime.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/picker.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/picker.date.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/picker.time.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/legacy.js"></script>

<script type="text/javascript" src="../assets/js/core/app.js"></script>
<script type="text/javascript" src="../assets/js/pages/picker_date.js"></script>

<script type="text/javascript" src="../assets/js/plugins/ui/ripple.min.js"></script>

<!-- Theme JS files -->
<script type="text/javascript" src="../assets/js/core/libraries/jquery_ui/interactions.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/forms/selects/select2.min.js"></script>

<script type="text/javascript" src="../assets/js/core/app.js"></script>
<script type="text/javascript" src="../assets/js/pages/form_select2.js"></script>

<script type="text/javascript" src="../assets/js/plugins/ui/ripple.min.js"></script>

</head>

<body id="background" class="layout-boxed navbar-bottom backpic">

	<!-- Main navbar AND Main menu-->
    <?php

        require_once '../Menu/menu_admin.php';

    ?>
    <!-- /page header -->


	<!-- Page container -->
	<div class="page-container">
		<!-- Page content -->
		<div class="page-content">
			<!-- Main content -->
			<div class="content-wrapper">
				<!-- Traffic sources -->
				<div class="panel panel-flat">
					<div class="panel-heading">
						<h6 class="panel-title">Clients Management</h6>
					</div>

                    <?php
                                if(isset($_GET['err']) )
                                {	
                                    if($_GET['err'] == 3 )
                                    {
                                    echo "<a href='clients.php'><div class='alert alert-success alert-dismissible' role='alert'>
                                             <strong>Success!</strong> New Client was successfully Created .
                                          </div></a>";
                                    }		
                                    
                                    
                                    if($_GET['err'] == 5 )
                                    {
                                    echo "<a href='clients.php'><div class='alert alert-success alert-dismissible' role='alert'>
                                        <strong>Success!</strong> Clients details where updated successfully.
                                        </div></a>";
                                    }	
                                    
                                    if($_GET['err'] == 4 )
                                    {
                                    echo "<a href='clients.php'><div class='alert alert-success alert-dismissible' role='alert'>
                                        <strong>Success!</strong> Clients profile was deleted successfully.
                                        </div></a>";
                                    }
                                            
                               

                                if($_GET['err'] == 6 )
                                {
                                echo "<a href='clients.php'><div class='alert alert-warning alert-dismissible' role='alert'>
                                    <strong>Warning!</strong> Sorry the National Registaration Number Entered Already Exists .
                                    </div></a>";
                                }

                                if($_GET['err'] == 2 )
                                {
                                echo "<a href='clients.php'><div class='alert alert-warning alert-dismissible' role='alert'>
                                    <strong>Sorry!</strong> The NRC that was provided already exists.
                                    </div></a>";
                                }
                                
                                if($_GET['err'] == 10 )
                                {
                                echo "<a href='clients.php'><div class='alert alert-success alert-dismissible' role='alert'>
                                    <strong>Success!</strong> Refrence number was assinged to the client Successfully.
                                    </div></a>";
                                }

                                if($_GET['err'] == 11 )
                                {
                                echo "<a href='clients.php'><div class='alert alert-warning alert-dismissible' role='alert'>
                                    <strong>Warning!</strong> Refrence  number has already been assinged.
                                    </div></a>";
                                }

                                if($_GET['err'] == 12 )
                                {
                                echo "<a href='clients.php'><div class='alert alert-danger alert-dismissible' role='alert'>
                                    <strong>Declined!</strong> You just declined one client profile.
                                    </div></a>";
                                }
                                
                            }
                        ?>
                    
					<div class="container-fluid" style="margin-top:5px;">
						<div class="row">
						<div class="col-lg-2">
								<ul class="list-inline text-center">
									<li>
										<a href="#" class="btn border-teal text-teal btn-flat btn-rounded btn-icon btn-xs valign-text-bottom"><i class="icon-people"></i></a>
									</li>
									<li class="text-left">
											<div class="text-semibold">Total Clients</div>
											<div class="text-muted top-1"><span class="status-mark border-success position-left"></span><?php echo $row2['yonse'];?></div>
									</li>
								</ul>

								<div class="col-lg-10 col-lg-offset-1">
									<div class="content-group" id="new-visitors"></div>
								</div>
							</div>
							<div class="col-lg-2">
								<ul class="list-inline text-center">
									<li>
										<a href="#" class="btn border-teal text-teal btn-flat btn-rounded btn-icon btn-xs valign-text-bottom"><i class="icon-checkmark3"></i></a>
									</li>
									<li class="text-left">
											<div class="text-semibold">Active Clients </div>
											<div class="text-muted top-1"><span class="status-mark border-success position-left"></span><?php echo $row1['active'];?></div>
									</li>
								</ul>
								<div class="col-lg-10 col-lg-offset-1">
									<div class="content-group" id="new-visitors"></div>
								</div>
							</div>
							<div class="col-lg-2">
								<ul class="list-inline text-center">
									<li>
										<a href="#" class="btn border-danger-400 text-danger-400 btn-flat btn-rounded btn-icon btn-xs valign-text-bottom"><i class="icon-blocked"></i></a>
									</li>
									<li class="text-left">
											<div class="text-semibold">Declined Clients</div>
											<div class="text-muted top-1"><span class="status-mark border-success position-left"></span> <?php echo $row3['bamapulobuleme'];?></div>
									</li>
								</ul>
								<div class="col-lg-10 col-lg-offset-1">
									<div class="content-group" id="new-sessions"></div>
								</div>
							</div>
                            <div class="col-lg-2">
								<ul class="list-inline text-center">
									<li>
										<a href="#" class="btn border-danger-400 text-danger-400 btn-flat btn-rounded btn-icon btn-xs valign-text-bottom"><i class="icon-blocked"></i></a>
									</li>
									<li class="text-left">
											<div class="text-semibold">Deactivated Clients</div>
											<div class="text-muted top-1"><span class="status-mark border-success position-left"></span><?php echo $row4['bantota'];?></div>
									</li>
								</ul>
								<div class="col-lg-10 col-lg-offset-1">
									<div class="content-group" id="new-sessions"></div>
								</div>
							</div>
                            <div class="col-lg-2">
								<ul class="list-inline text-center">
									<li>
										<a href="#" class="btn border-warning-400 text-warning-400 btn-flat btn-rounded btn-icon btn-xs valign-text-bottom"><i class="icon-blocked"></i></a>
									</li>
									<li class="text-left">
											<div class="text-semibold">Pending Clients</div>
											<div class="text-muted top-1"><span class="status-mark border-success position-left"></span><?php echo $row5['bamoyo'];?></div>
									</li>
								</ul>
								<div class="col-lg-10 col-lg-offset-1">
									<div class="content-group" id="new-sessions"></div>
								</div>
							</div>
                            <!--
							<div class="col-lg-2">
								<ul class="list-inline text-center">
									<li>
                                        <a href="#" class="btn border-indigo-400 text-indigo-400 btn-flat btn-rounded btn-icon btn-xs valign-text-bottom" data-toggle="modal" data-target="#myModal"><i class="icon-plus3"></i></a>
									</li>
									<li class="text-left">
										<div class="text-semibold">Add New Client</div>
										<div class="text-muted top-1"><span class="status-mar border-success position-left"></span></div>
									</li>
								</ul>
								<div class="col-lg-10 col-lg-offset-1">
									<div class="content-group" id="total-online"></div>
								</div>
							</div>-->
						</div>
					</div>
                    <hr>
                    <div id="reportsTable" style="width:98%;margin:auto;">
                     <table id="example" class="display" style="width:100%;font-size:10px;">
                         <thead>
                             <tr>
                             <th>Name,</th>
                                 <th>Mobile</th>
                                 <th>NRC</th>
                                 <th>Gender</th>
                                 <th>DOB</th>
                                 <th>RefNum</th>
                                 <th>Cover</th>
                                 <th>Premium Type</th>
                                 <th>Status</th>
                                 <th>Actions</th>
                             </tr>
                         </thead>
                         <tbody>
                         <?php              	      	
		
// Check connection
									if ($conn->connect_error) {
										die("Connection failed: " . $conn->connect_error);
									} 
//Query selecting all data from the database_table issues
									$sql = "SELECT* FROM clients";
										$result = $conn->query($sql);
									if ($result->num_rows > 0) {
										while($row = $result->fetch_assoc()) {
                                            $id = $row['clientID'];
                                            $PREM= $row["primiumType"];

                                        $sql1    = "SELECT `premName`,`premiun_cover` FROM `premiums` WHERE `premCode`= '$PREM'";
                                        $result1 = $conn->query($sql1);
                                        $rows    = $result1->fetch_assoc();

                                        echo"<tr class='odd gradeX'>
                                                <td style='text-align:center;'>{$row["clientName"]}</td>
                                                <td style='text-align:center;'>{$row["mobile"]}</td>
                                                <td style='text-align:center;'>{$row["NRC"]}</td>
                                                <td style='text-align:center;'>{$row["gender"]}</td>
                                                <td style='text-align:center;'>{$row["dateOfbirth"]}</td>
                                                <td style='text-align:center;'>{$row["policyNumber"]}</td>
                                                <td style='text-align:center;'>K {$rows["premiun_cover"]}</td>
                                                <td style='text-align:center;'>{$rows["premName"]}</td>
                                                <td style='text-align:center;'>{$row["status"]}</td>
                                                <td style='text-align:center;width:50px;'>"; 
                                               
                                                if($row['status']=='Active'){
                                                    echo"<input type='button' name='edit' value='Edit' id='$id' class='edit_data  btn btn-info btn-xs batoz'/>";
                                                }
                                                if($row['status']=='Pending'){
                                                    echo"<a href=\"agent_activation.php?id=" . $row['clientID'] ."\" class='btn btn-warning batoz' > Pending </a>";
                                                }
                                                if($row['status']=='Disabled'){
                                                    echo"<input type='button' name='edit' value='Edit' id='$id' class='edit_data  btn btn-info btn-xs batoz'/>";
                                                }
                                                echo"</td>
                                    </tr>";
                                        }}
                            ?>
							</tbody>
							</table>
                   </div>
				</div>
                <!-- /traffic sources -->
                <!-- Modal content number1 starts here-->
                <div class="modal fade" id="myModal" role="dialog">
                        <div class="modal-dialog">
                        <!-- Modal content-->
                        <div class="modal-content">
                            <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title">Clients Details</h4>
                            </div>
                            <div class="modal-body">
                            <form class="form-horizontal" action="createClient.php" method="POST" role="form">
                                <fieldset class="content-group">
                                    <legend class="text-bold" style="font-size:10px;color:red;"><i>All fields are required*</i></legend>

                                    <div class="form-group client1">
                                        <label class="control-label col-lg-4" style="text-align:right;">Clients Name</label>
                                        <div class="col-lg-6">
                                            <div class="input-group input-group-xlg">
                                                <span class="input-group-addon"></span>
                                                <input type="text"  class="form-control" name="names" required autocomplete="off">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group client1">
                                        <label class="control-label col-lg-4" style="text-align:right;">National Registration Number</label>
                                        <div class="col-lg-6">
                                            <div class="input-group input-group-lg">
                                                <span class="input-group-addon"></span>
                                                <input type="text" class="form-control" name="nrc" maxlength="9"  required autocomplete="off">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group client1">
                                        <label class="control-label col-lg-4" style="text-align:right;">Date Of Birth</label>
                                        <div class="col-lg-6">
                                            <div class="input-group">
                                                <span class="input-group-addon"></span>
                                                <input type="date" class="form-control" name="dateOfBirth"  required autocomplete="off">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group client1">
                                        <label class="control-label col-lg-4" style="text-align:right;">Client Mobile Number(260)</label>
                                        <div class="col-lg-6">
                                            <div class="input-group input-group-sm">
                                                <span class="input-group-addon"></span>
                                                <input type="text" class="form-control"  name="mobile" maxlength="12"  required autocomplete="off">
                                                <input type="hidden" class="form-control" name='month' value="<?php echo date('m');?>">
                                                <input type="hidden" class="form-control" name='year' value="<?php echo date('Y');?>">
                                                <input type="hidden" class="form-control" name='status' value="Pending">
                                            </div>
                                        </div>
                                    </div>

                                     <div class="form-group client1">
                                        <label class="control-label col-lg-4" style="text-align:right;">Clients Gender</label>
                                        <div class="col-lg-6">
                                        <select class="select" name="gender" required>
                                                <option value="">Select Gender</option>
                                                <option value="Male">Male</option>
                                                <option value="Female">Female</option>
                                        </select>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group client1">
                                        <label class="control-label col-lg-4" style="text-align:right;">Policy Type</label>
                                        <div class="col-lg-6">
                                        <select class="select" name="policyType" required>
                                                <option value="">Select Policy Type</option>
                                                <option value="Tontozo Core Cover">Tontozo Core Cover</option>
                                                <option value="Tontozo Senior Cover">Tontozo Senior Cover</option>
                                        </select>
                                        </div>
                                    </div>

                                     <div class="form-group client1">
                                        <label class="control-label col-lg-4" style="text-align:right;">Select Policy</label>
                                        <div class="col-lg-6">
                                        <select class="select" name="policy" required>
                                                <option value="">Select Policy</option>
                                                <option value="Individual">Individual</option>
                                                <option value="Family">Family</option>
                                        </select>
                                        </div>
                                    </div>

                                     <div class="form-group client1">
                                        <label class="control-label col-lg-4" style="text-align:right;">Select Cover</label>
                                        <div class="col-lg-6">
                                        <select class="select" name="cover" required>
                                                <option value="">Select Cover</option>
                                                <option value="2500">K2500</option>
                                                <option value="5000">K5000</option>
                                                <option value="10000">K1000</option>
                                                <option value="15000">K15000</option>
                                                <option value="20000">K20000</option>
                                        </select>
                                        </div>
                                    </div>

                                     <div class="form-group client1">
                                        <label class="control-label col-lg-4" style="text-align:right;">Select Premium</label>
                                        <div class="col-lg-6">
                                        <select class="select" name='premiumType' required>
                                                <option value="">Select Premium</option>
                                            <?php
												$sql  = "SELECT* FROM `premiums`";
												$result = mysqli_query($conn, $sql);
												
												if (mysqli_num_rows($result) > 0) {
													// output data of each row
													while($row = mysqli_fetch_assoc($result)) {
													
														echo"<option value =" . $row['premCode'] ."> " . $row['premName'] . " </option>";
													
													}
												}
											?>
                                        </select>
                                        </div>
                                    </div>
                                </fieldset>
                                <div class="btn-group btn-group-xs" style="margin-left:50px;">
                                    <button type="submit" name="submit" class="btn btn-success" style="height:24px;line-height:4px;">Add Client</button>
                                </div>
                            </form>
                            </div>
                        </div>
                    </div>
                 </div>

    <!--Edit Item Modal -->
        <div id="add_data_modal" class="modal fade" >
            <form action="edit3.php" method="POST" class="form-horizontal" role="form">
                <div class="modal-dialog modal-lg">
                    <!-- Modal content-->
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title">Update Clients Profile</h4>
                        </div>
                        <div class="modal-body">
                            <input type="hidden" name="client_id" id="client_id">
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="item_name">Clients Name:</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" id="names" name="names"  required>
                                </div>
                                <label class="control-label col-sm-2" for="item_code">Clents NRC:</label>
                                <div class="col-sm-4">
                                    <input type="text"  class="form-control" id="nrc" maxlength="9" name="nrc"  required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="item_name">Date Of Birth:</label>
                                <div class="col-sm-4">
                                    <input type="date" class="form-control" id="dob" name="dob"  required >
                                </div>
                                <label class="control-label col-sm-2" for="item_code">Clients Mobile:</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" id="mobile" maxlength="12"  name="mobile" required>
                                </div>
                            </div>
                            <div class="modal-body">
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="item_name">Gender:</label>
                                <div class="col-sm-4">
                                <select class="select" name="gender" id="gender"  required>
                                        <option value="">Select Gender</option>
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                </select>
                                </div>
                                 <label class="control-label col-sm-2" for="item_code">Select Cover:</label>
                                <div class="col-sm-4">

                                        <select class="select" name='premiumType' id='cover' required>
                                                <option value="">Select Cover</option>
                                            <?php
												$sql  = "SELECT* FROM `premiums`";
												$result = mysqli_query($conn, $sql);
												
												if (mysqli_num_rows($result) > 0) {
													// output data of each row
													while($row = mysqli_fetch_assoc($result)) {
													
                                                        echo"<option value =" . $row['premCode'] ."> " . $row['premiun_cover'] ." - ".$row['premName']." </option>";
													
													}
												}
											?>
                                        </select>
                            </div>
                            </div>
                            
                                <label class="control-label col-sm-2" for="item_code">Select Status:</label>
                                <div class="col-sm-4">
                                <select class="select" name="status" id="status" required>
                                            <option value="">Select Status</option>
                                            <option value="Active">Activate</option>
                                            <option value="Disabled">Disable</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="item_name">Policy Number:</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" name="policyNumber" id="policyNumber"   required >
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-8">
                                <div class="modal-footer">
                                
                            </div>
                        </div>
                    </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary batoz" name="insert" id ="insert"> Update</button>
                            <button type="button" class="btn btn-warning batoz" data-dismiss="modal"> Cancel</button>
                        </div>
                    </div>
                </div>

                    <script>
                    $(document).ready(function(){
                    
                    $(document).on('click', '.edit_data', function(){
                        var client_id = $(this).attr("id");
                        $.ajax({
                            url:"fetch_client.php",
                            method:"POST",
                            data:{client_id:client_id},
                            dataType:"json",
                            success:function(data){
                                $('#names').val(data.clientName);
                                $('#nrc').val(data.NRC);
                                $('#dob').val(data.dateOfbirth);
                                $('#mobile').val(data.mobile);
                                $('#gender').val(data.gender);
                                $('#policyType').val(data.policyType);
                                $('#policy').val(data.policy);
                                $('#cover').val(data.cover);
                                $('#premiumType').val(data.primiumType);
                                $('#profileReason').val(data.profileReason);
                                $('#status').val(data.status);
                                $('#policyNumber').val(data.policyNumber);
                                $('#client_id').val(data.clientID);
                                $('#insert').val("update");
                                $('#add_data_modal').modal('show');
                                
                            }
                        
                        });
                    
                    });
                    
                });
            </script>
           
            </div>
                </form>
                </div>
            </div>
            <!-- /content area -->
        </div>
            <!-- /page content -->
    </div>
    <!-- /page container -->
   
    <script>	
		$(document).ready(function() {
			$('#example').DataTable( {
				dom: 'Bfrtip',
				buttons: [
					{
						extend: 'copyHtml5',
						title: 'Uniturtule Transactions'
					},
					{
						extend: 'excelHtml5',
						title: 'Uniturtule Transactions'
					},
					{
						extend: 'csvHtml5',
						title: 'Uniturtule Transactions'
					},
					{
						extend: 'pdfHtml5',
						title: 'Uniturtule Transactions',
						orientation: 'landscape',
                		pageSize: 'LEGAL'
					},
					{
						extend: 'print',
						title: 'Uniturtule Transactions',
						orientation: 'landscape',
                		pageSize: 'LEGAL'
					}
				]
			} );
		} );
</script>
    
        <!-- /core JS for tables -->
        <script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.flash.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.print.min.js"></script>
        <script>
            $(document).ready(function () {
                $(document).on('click', '.get_client_id', function(){
                    var id = $(this).attr("id");
                    $('#id').val(id);
                    $('#myModal2').modal('show');
                })
             })
        </script>
        <!-- /core JS for tables -->

	<!-- footer-->
    <?php

require_once '../footer/footer.php';

?>
<!-- /Footer -->
</body>
</html>
