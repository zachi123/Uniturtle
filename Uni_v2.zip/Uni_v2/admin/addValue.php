<?php
	  
      require_once '../config/session.php';
      require_once '../config/db_con.php';

      if(isset($_POST["submit"]))
		   $id = $_GET['id'];
	  { // <--- declare id here
	   echo $date						    =$_POST["date"];
	   echo $loadBy						    =$_POST["loader"];
	   echo $Amounts						=$_POST["amount"];
	   echo $TransactionRef				    =$_POST["RefNumber"];
	   echo $TeminalID					    =$_POST["teminalID"];
	   echo $AgentID						=$_POST["AgentID"];

	   
	  
	   $sql = "INSERT INTO value(`valueID`, `AgentID`, `date`, `TeminalID`, `AmountCredit`, `loadedBy`, `transactionRef`)
	   VALUES ('','$AgentID','$date','$TeminalID','$Amounts','$loadBy','$TransactionRef')";		   
	   $conn->query($sql);

	   
	   // Update the Audit taril table for this action by the user who has logged in//
	    $msg ="Loaeded value for the Agent with details TerminalID: " . $TeminalID . " , AgentID : " . $AgentID .", Amounts :K" . $Amounts.", Date :". $date.", ReceiptNumber :R". $receipt;
		$userID					= $_SESSION['sess_userID'];
		$ActionDate    		 	= date("Y-m-d h:i:sa");
		$ActionDoneBy			= $_SESSION['sess_firstname']." ".$_SESSION['sess_lastname'];
		$Action					= $msg;
		
		$log = "INSERT INTO `audit` (actionID, userID, actionDate, actionDoneBy, action)
		VALUES ('','$userID','$ActionDate','$ActionDoneBy','$Action')";
		$conn->query($log);
		
		
		///QUERY THAT ADDS UPLOADED BALANCE AND CURRENT BALANCE
		$sqlSum = "SELECT SUM(AvailableBalance) AS value_sum FROM merchants WHERE agentID ='$AgentID'";
		$result = $conn->query($sqlSum);
		$row1 = $result->fetch_assoc();
		$sum 	= $row1['value_sum'] + $Amounts;
		
		///QUERY THAT GETS CLIENTS DETAILS FOR SMS 
		$sqlmobile = "SELECT `mobile`,`firstName` FROM `merchants` WHERE agentID ='$AgentID'";
		$result = $conn->query($sqlmobile);
		$row2 = $result->fetch_assoc();
		
		
		$update = "UPDATE `merchants` SET `AvailableBalance`='$sum' WHERE `agentID`=$AgentID";		   
		$conn->query($update);
		
		$mobile = $row2['mobile'];
		$fname 	= $row2['firstName'];
		$msg    = "Dear"." ". $fname ." you have loaded K".$Amounts ." into you account and your new balance is K".$sum ."  REF: ". $TransactionRef  ;
		
	    echo $query = http_build_query([
			'username' 	=> 'probase',
			'password' 	=> 'probase',
			'mobiles' 	=> 	$mobile,
			'message' 	=>	$msg,
			'sender' 	=> 'UNITURTLE',
			'type' 		=> 'TEXT'
		]);
		
		$url = "http://smsapi.probasesms.com/apis/text/index.php?".$query;
		//var_dump($url);
		
		// Get cURL resource
		$curl = curl_init();
		// Set some options - we are passing in a useragent too here
		curl_setopt_array($curl, array(
			CURLOPT_RETURNTRANSFER => 1,
			CURLOPT_URL => $url,
			CURLOPT_USERAGENT => 'uniturtle'
		));
		// Send the request & save response to $resp
		$resp = curl_exec($curl);
		// Close request to clear up some resources
		curl_close($curl);

	 
            header("location:loadValue.php?id=".$AgentID);
			//echo "<script>window.open('loadValue.php?err=5','_self');</script>";

		  
	  }
	  
	        
?>