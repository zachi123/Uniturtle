<?php
	require_once '../config/session.php';
    require_once '../config/db_con.php';		
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Uniturtle</title>

<!-- Global stylesheets -->
<link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
<link href="../assets/css/icons/icomoon/styles.css" rel="stylesheet" type="text/css">
<link href="../assets/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="../assets/css/core.css" rel="stylesheet" type="text/css">
<link href="../assets/css/components.css" rel="stylesheet" type="text/css">
<link href="../assets/css/colors.css" rel="stylesheet" type="text/css">
<!-- /global stylesheets -->


<!-- Global for the table -->
<link href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css">
<link href="https://cdn.datatables.net/buttons/1.5.2/css/buttons.dataTables.min.css" rel="stylesheet" type="text/css">
<!-- Global for the table -->

<!-- Core JS files -->
<script type="text/javascript" src="../assets/js/plugins/loaders/pace.min.js"></script>
<script type="text/javascript" src="../assets/js/core/libraries/jquery.min.js"></script>
<script type="text/javascript" src="../assets/js/core/libraries/bootstrap.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/loaders/blockui.min.js"></script>
<!-- /core JS files -->

<script type="text/javascript" src="../assets/js/plugins/notifications/jgrowl.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/ui/moment/moment.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/daterangepicker.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/anytime.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/picker.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/picker.date.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/picker.time.js"></script>
<script type="text/javascript" src="../assets/js/plugins/pickers/pickadate/legacy.js"></script>

<script type="text/javascript" src="../assets/js/core/app.js"></script>
<script type="text/javascript" src="../assets/js/pages/picker_date.js"></script>

<script type="text/javascript" src="../assets/js/plugins/ui/ripple.min.js"></script>

<!-- Theme JS files -->
<script type="text/javascript" src="../assets/js/core/libraries/jquery_ui/interactions.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/forms/selects/select2.min.js"></script>

<script type="text/javascript" src="../assets/js/core/app.js"></script>
<script type="text/javascript" src="../assets/js/pages/form_select2.js"></script>

<script type="text/javascript" src="../assets/js/plugins/ui/ripple.min.js"></script>

</head>

<body id="background" class="layout-boxed navbar-bottom backpic">

	<!-- Main navbar AND Main menu-->
    <?php

        require_once '../Menu/menu_admin.php';

    ?>
    <!-- /page header -->


	<!-- Page container -->
	<div class="page-container">
		<!-- Page content -->
		<div class="page-content" id="Div1">
			<!-- Main content -->
			<div class="content-wrapper">
				<!-- Traffic sources -->
				<div class="panel panel-flat">
					<div class="panel-heading">
						<h6 class="panel-title">User Management</h6>
                    </div>
						

						 <?php
                            if(isset($_GET['err']) )
                            {	
                                if($_GET['err'] == 3 )
                                {
									echo "<a href='users.php'><div class='alert alert-success alert-dismissible' role='alert'>
                                    <strong>Success!</strong> New user was added successfully.
                                    </div></a>";
                                }		
                                
                                
                                if($_GET['err'] == 5 )
                                {
									echo "<a href='users.php'><div class='alert alert-success alert-dismissible' role='alert'>
                                    <strong>Success!</strong> User details where updated successfully.
                                    </div></a>";
                                }
                                
                                if($_GET['err'] == 6 )
                                {
									echo "<a href='users.php'><div class='alert alert-success alert-dismissible' role='alert'>
                                    <strong>Success!</strong> User password was reset successfully.
                                    </div></a>";
                                }

                                if($_GET['err'] == 4 )
                                {
									echo "<a href='users.php'><div class='alert alert-success alert-dismissible' role='alert'>
                                    <strong>Success!</strong> A User was Disabled Successfully.
                                    </div></a>";
                                }
                                        
                            }
                ?>
					<div class="container-fluid" style="margin-top:-50px;">
						<div class="row">
							<div class="col-lg-3" style="float:right;">
								<ul class="list-inline text-center">
									<li>
                                        <a href="#" class="btn border-indigo-400 text-indigo-400 btn-flat btn-rounded btn-icon btn-xs valign-text-bottom" data-toggle="modal" data-target="#myModal"><i class="icon-plus3"></i></a>
									</li>
									<li class="text-left">
										<div class="text-semibold">Add New User</div>
										<div class="text-muted top-1"><span class="status-mar border-success position-left"></span></div>
									</li>
								</ul>
								<div class="col-lg-10 col-lg-offset-1">
									<div class="content-group" id="total-online"></div>
								</div>
							</div>
						</div>
					</div>
                    <div id="reportsTable" style="width:98%;margin:auto;">
                     <table id="example" class="display" style="width:100%;font-size:10px;">
					 <thead>
                        <tr>
                        <th>FirstName</th>
                        <th>LastName</th>
                        <th>Mobile</th>
                        <th>Gender</th>
                        <th>UserName</th>
                        <th>Email</th>
                        <th>Status</th>
                        <th>Role</th>
                        <th style="width:100px;">Action</th>
                        </tr>
                        </thead>
					<tbody>
                    <?php                              
// Create connection
								$conn = new mysqli($servername, $username, $password, $dbname);		      	
		
// Check connection
									if ($conn->connect_error) {
										die("Connection failed: " . $conn->connect_error);
									} 
//Query selecting all data from the database_table issues
									$sql = "SELECT* FROM users";
										$result = $conn->query($sql);
									if ($result->num_rows > 0) {
										while($row = $result->fetch_assoc()) {
                                            $id = $row['userID'];
                                   echo"<tr class='odd gradeX'>
                                        <td>{$row["firstname"]}</td>
                                        <td>{$row["lastname"]}</td>
                                        <td>{$row["mobile"]}</td>
                                        <td>{$row["gender"]}</td>
                                        <td>{$row["username"]}</td>
                                        <td>{$row["email"]}</td>
                                        <td>{$row["status"]}</td>
                                        <td>{$row["role"]}</td>
                                        <td>
                                            &nbsp;
                                            <a href=\"update_user.php?id=" . $row['userID'] ."\" class='edit_datas  btn btn-info btn-xs batoz'>Update</a>
											&nbsp;
											<input type='button' name='edit' value='View' id='$id' class='edit_data  btn btn-info btn-xs batoz'/>";
											
										echo"</td>
                                    </tr>";
			}}
?>
                    </tbody>
                     </table>
                   </div>
				</div>
                <!-- /traffic sources -->
                <!-- Modal content number1 starts here-->
                <div class="modal fade" id="myModal" role="dialog">
                        <div class="modal-dialog">
                        <!-- Modal content-->
                        <div class="modal-content">
                            <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title">Add New User</h4>
                            </div>
                            <div class="modal-body">
                            <form class="form-horizontal" action="createUser.php" method="POST">
                                <fieldset class="content-group">
                                    <legend class="text-bold" style="font-size:10px;color:red;"><i>All fields are required*</i></legend>

                                    <div class="form-group client1">
                                        <label class="control-label col-lg-4" style="text-align:right;">First Name</label>
                                        <div class="col-lg-6">
                                            <div class="input-group input-group-xlg">
                                                <span class="input-group-addon"></span>
                                                <input type="text" class="form-control" name="fname" required autocomplete="off">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group client1">
                                        <label class="control-label col-lg-4" style="text-align:right;">Last Name</label>
                                        <div class="col-lg-6">
                                            <div class="input-group input-group-lg">
                                                <span class="input-group-addon"></span>
                                                <input type="text" class="form-control"  name="lname" required autocomplete="off">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group client1">
                                        <label class="control-label col-lg-4" style="text-align:right;">UserName</label>
                                        <div class="col-lg-6">
                                            <div class="input-group">
                                                <span class="input-group-addon"></span>
                                                <input type="text" class="form-control"  name="username" required autocomplete="off">
                                            </div>
                                        </div>
                                    </div>

                                     <div class="form-group client1">
                                        <label class="control-label col-lg-4" style="text-align:right;">Email Address</label>
                                        <div class="col-lg-6">
                                            <div class="input-group">
                                                <span class="input-group-addon"></span>
                                                <input type="text" class="form-control"  name="email" required autocomplete="off">
                                            </div>
                                        </div>
                                    </div>

                                     <div class="form-group client1">
                                        <label class="control-label col-lg-4" style="text-align:right;">Mobile Number</label>
                                        <div class="col-lg-6">
                                            <div class="input-group">
                                                <span class="input-group-addon"></span>
                                                <input type="text" class="form-control"  name="mobile" required autocomplete="off">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group client1">
                                        <label class="control-label col-lg-4" style="text-align:right;">Gender</label>
                                        <div class="col-lg-6">
                                        <select class="select" name="gender" required>
                                                <option value="">Select Gender</option>
                                                <option value="Male">Male</option>
                                                <option value="Female">Female</option>
                                        </select>
                                        </div>
                                    </div>

                                     <div class="form-group client1">
                                        <label class="control-label col-lg-4" style="text-align:right;">Select Status</label>
                                        <div class="col-lg-6">
                                        <select class="select" name="status" required>
                                                <option value="">Select Status</option>
                                                <option value="Active">Active</option>
                                                <option value="Disabled">Disabled</option>
                                        </select>
                                        </div>
                                    </div>
                                    <?php
											function random_password( $length = 6 ) {
												$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$";
												$password = substr( str_shuffle( $chars ), 0, $length );
												return $password;
											}
										?>
										
										<input type="hidden" class="form-control input-sm" name='pass' value="<?php echo $password = random_password(6);?>">

                                    <div class="form-group client1">
                                        <label class="control-label col-lg-4" style="text-align:right;">Select Role</label>
                                        <div class="col-lg-6">
                                        <select class="select" name="role" required>
                                                <option value="">Select Role</option>
                                                <option value="admin">Admin</option>
                                                <option value="user">User</option>
                                        </select>
                                        </div>
                                    </div>
                                </fieldset>
                                <div class="btn-group btn-group-xs" style="margin-left:50px;">
                                    <button type="submit" name="submit" class="btn btn-success" style="height:24px;line-height:4px;">Add User</button>
                                </div>
                            </form>
                            </div>
                        </div>
                        </div>
                    </div>
                    </div>
            <!-- /content area -->
 <!-- Modal content number2  for editing the clients details after decline starts here-->
                   
        <!--View User Details Modal -->
        <div id="add_data_modal" class="modal fade" >
            <form action="edit1.php" method="POST" class="form-horizontal" role="form">
                <div class="modal-dialog modal-lg">
                    <!-- Modal content-->
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title">User Profile Details</h4>
                        </div>
                        <div class="modal-body">
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="item_name">Fist Name:</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" id="firstname"   disabled >
                                </div>
                                <label class="control-label col-sm-2" for="item_code">Last Name:</label>
                                <div class="col-sm-4">
                                    <input type="text"  class="form-control" id="lastname"  disabled>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="item_name">User Name:</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" id="username"   disabled >
                                </div>
                                <label class="control-label col-sm-2" for="item_code">Email Address:</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" id="email"   disabled>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="item_name">Mobile Number:</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" id="mobile"  disabled >
                                </div>
                                <label class="control-label col-sm-2" for="item_code">Gender:</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" id="gender"  disabled>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="item_code">Status:</label>
                                <div class="col-sm-4">
                                    <input type="text"  class="form-control" id="status"  disabled>
                                </div>
                                <label class="control-label col-sm-2" for="item_code">Role:</label>
                                <div class="col-sm-4">
                                    <input type="text"  class="form-control" id="role"   disabled>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-warning batoz" data-dismiss="modal"> Close</button>
                        </div>
                    </div>
                </div>

            <script>
                    $(document).ready(function(){
                    
                    $(document).on('click', '.edit_data', function(){
                        var userID = $(this).attr("id");
                        $.ajax({
                            url:"fetch_user_details.php",
                            method:"POST",
                            data:{userID:userID},
                            dataType:"json",
                            success:function(data){
                                $('#firstname').val(data.firstname);
                                $('#lastname').val(data.lastname);
                                $('#username').val(data.username);
                                $('#email').val(data.email);
                                $('#mobile').val(data.mobile);
                                $('#gender').val(data.gender);
                                $('#status').val(data.status);
                                $('#role').val(data.role);
                                $('#insert').val("update");
                                $('#add_data_modal').modal('show');
                                
                            }
                        
                        });
                    
                    });
                    
                });
            </script>
    <!--Edit Item Modal -->
            </div>
            </div>
        </div>
            <!-- /page content -->
    </div>
	<!-- /page container -->
    <script>	
		$(document).ready(function() {
			$('#example').DataTable( {
				dom: 'Bfrtip',
				buttons: [
					{
						extend: 'copyHtml5',
						title: 'Uniturtule Transactions'
					},
					{
						extend: 'excelHtml5',
						title: 'Uniturtule Transactions'
					},
					{
						extend: 'csvHtml5',
						title: 'Uniturtule Transactions'
					},
					{
						extend: 'pdfHtml5',
						title: 'Uniturtule Transactions',
						orientation: 'landscape',
                		pageSize: 'LEGAL'
					},
					{
						extend: 'print',
						title: 'Uniturtule Transactions',
						orientation: 'landscape',
                		pageSize: 'LEGAL'
					}
				]
			} );
		} );
</script>
    
        <!-- /core JS for tables -->
        <script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.flash.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.print.min.js"></script>
        <!-- /core JS for tables -->

	<!-- footer-->
<?php

    require_once '../footer/footer.php';

?>
<!-- /Footer -->
</body>
</html>
